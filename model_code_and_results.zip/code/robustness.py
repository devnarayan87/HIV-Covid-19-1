"""Structural robustness: named model variants, each re-calibrated, with all scenarios
and the elasticities of R_H and R_C (results/G_robustness.json)."""
import json, time
import numpy as np
import jax.numpy as jnp
from common import *
from calibrate import calibrate, TARGETS
import calibrate as cal
from scenarios import all_scenarios

prim0 = load_primitive()
VARIANTS = {
    "baseline": {},
    "no deprivation gradients": {"g_crowd": 0.0, "g_vac": 0.0, "g_art": 0.0, "g_fatal": 0.0},
    "doubled deprivation gradients": {"g_crowd": 2.0, "g_vac": 2.0, "g_art": 2.0, "g_fatal": 2.0},
    "crowding gradient only": {"g_vac": 0.0, "g_art": 0.0, "g_fatal": 0.0},
    "access gradients only": {"g_crowd": 0.0, "g_fatal": 0.0},
    "fatality gradient only": {"g_crowd": 0.0, "g_vac": 0.0, "g_art": 0.0},
    "immune escape 0.3": {"_chi": 0.3},
    "immune escape 0.7": {"_chi": 0.7},
    "low HIV fatality multipliers": {"HR_L": 1.2, "HR_U": 2.0, "HR_T": 1.1},
    "high HIV fatality multipliers": {"HR_L": 2.2, "HR_U": 4.5, "HR_T": 1.5},
    "care effect 0.15": {"psi": 0.15},
    "care effect 0.45": {"psi": 0.45},
    "R_C = 2.4": {"_RC": 2.4},
    "R_C = 3.6": {"_RC": 3.6},
    "KP partnerships 6/yr": {"c_high": 6.0},
    "KP partnerships 15/yr": {"c_high": 15.0},
    "2023 HIV targets (0.22 %, 69 %)": {"_targets": (0.0022, 0.69)},
}


def elasticity(fun, p, key, h=1e-3):
    up = fun({**p, key: p[key] * (1 + h)}); dn = fun({**p, key: p[key] * (1 - h)})
    return (np.log(up) - np.log(dn)) / (2 * h)


out = {}
for name, ov in VARIANTS.items():
    t0 = time.time()
    q = {**prim0}
    chi = ov.get("_chi", 0.5); RC = ov.get("_RC", 3.0)
    for k, v in ov.items():
        if not k.startswith("_"):
            q[k] = v
    old = dict(cal.TARGETS)
    if "_targets" in ov:
        cal.TARGETS["adult_prev"], cal.TARGETS["art"] = ov["_targets"]
    try:
        prim, p, diag, (xH, xE, zH, zE) = calibrate(q, RC_target=RC)
    finally:
        cal.TARGETS.update(old)
    rh_fun = lambda pp: R_H(pp)[0]; rc_fun = lambda pp: R_C(pp)[0]
    el = {f"RH_{k}": elasticity(rh_fun, p, k) for k in ["betaH", "tau", "xi", "omega", "kappaU", "muU", "c_high"] if k != "c_high"}
    el.update({f"RC_{k}": elasticity(rc_fun, p, k) for k in ["betaC", "gamma", "iota1", "rho"]})
    rh, KH = R_H(p)
    nH = len(HIV_DFE); Pi = np.diag(np.tile(KPMASK, nH).astype(float)); Id = np.eye(KH.shape[0])
    res, _ = all_scenarios(p, xE, chi=chi)
    out[name] = {"overrides": {k: v for k, v in ov.items()}, "calib": {k: v for k, v in diag.items() if k != "history"},
                 "R_H": rh, "T_KP": spectral_radius(Pi @ KH @ np.linalg.inv(Id - (Id - Pi) @ KH)),
                 "kp_prev": kp_prev(xE), "elasticities": el, "scenarios": res, "time_s": time.time() - t0}
    s = res
    print(f"{name:34s} RH {rh:.4f} KP {100*kp_prev(xE):.2f}% deaths {s['S0']['covid_deaths_per100k']:.1f} "
          f"RR0 {s['S0']['RR_Q1_Q4']:.2f} RR4 {s['S4']['RR_Q1_Q4']:.2f} RR7 {s['S7']['RR_Q1_Q4']:.2f} "
          f"A4 {s['S4']['covid_deaths_averted_per100k']:.2f} A7 {s['S7']['covid_deaths_averted_per100k']:.2f} "
          f"A10 {s['S10']['covid_deaths_averted_per100k']:.2f} A9 {s['S9']['covid_deaths_averted_per100k']:.2f} "
          f"dHIV {100*(s['S1']['new_hiv_per100k']/s['S0']['new_hiv_per100k']-1):.1f}% t {time.time()-t0:.0f}s", flush=True)
    json.dump(out, open("results/G_robustness.json", "w"), indent=1, default=float)
