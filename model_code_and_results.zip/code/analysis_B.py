"""Threshold surfaces and bifurcation diagrams (results/B_thresholds.json)."""
import json
import numpy as np
import jax.numpy as jnp
from scipy.optimize import brentq
from common import *

p = P(); out = {}
# ---- R_H over ART initiation multiplier x proportional reduction in HIV transmission
mults = np.linspace(0.5, 2.5, 25); prevs = np.linspace(0, 0.15, 21)
RH = np.zeros((len(prevs), len(mults)))
for i, u3 in enumerate(prevs):
    for j, m in enumerate(mults):
        RH[i, j] = R_H({**p, "tau": p["tau"] * m, "prev_max": 1.0}, u=jnp.zeros(NCTRL).at[5].set(u3))[0]
out["RH_grid"] = {"art_mult": mults.tolist(), "prev": prevs.tolist(), "R": RH.tolist()}
f = lambda m: R_H({**p, "tau": p["tau"] * m})[0] - 1
mm = np.geomspace(0.25, 40.0, 60); fv = np.array([f(m) for m in mm])
out["RH_vs_art"] = {"mult": mm.tolist(), "RH": (fv + 1).tolist()}
out["RH_monotone_decreasing_in_tau"] = bool(np.all(np.diff(fv) < 0))
k = np.where((fv[:-1] > 0) & (fv[1:] < 0))[0]
out["art_mult_threshold"] = brentq(f, mm[k[0]], mm[k[0] + 1]) if len(k) else None
out["RH_xi_half"] = R_H({**p, "xi": p["xi"] / 2})[0]
out["RH_xi_double"] = R_H({**p, "xi": p["xi"] * 2})[0]
out["RH_art2_xi_half"] = R_H({**p, "xi": p["xi"] / 2, "tau": p["tau"] * 2})[0]
g = lambda u3: R_H({**p, "prev_max": 1.0}, u=jnp.zeros(NCTRL).at[5].set(u3))[0] - 1
out["prev_threshold"] = brentq(g, 0.0, 0.5)
out["RH_art_disrupt"] = R_H({**p, "art_disrupt": 0.5, "xi_mult": 2.0})[0]
# ---- R_C under sustained vaccination x test-and-isolate
vl = np.linspace(0, 1, 21); il = np.linspace(0, 1, 21)
RC = np.zeros((len(il), len(vl)))
for i, u4 in enumerate(il):
    for j, u1 in enumerate(vl):
        RC[i, j] = R_C(p, u=jnp.zeros(NCTRL).at[0:4].set(u1).at[6].set(u4))[0]
out["RC_grid"] = {"vac": vl.tolist(), "iso": il.tolist(), "R": RC.tolist()}
out["RC_min_on_grid"] = float(RC.min())
# ---- bifurcation diagrams by exact continuation (and multistart below threshold)
def covid_inf(x): return float(sum(x[IDX[k]] for k in ["E", "EV", "A", "I"]).sum())
base_rc = R_C(p)[0]; bif_c = []; z = None
for Rt in np.r_[np.linspace(4.0, 1.02, 40), np.linspace(1.0, 0.5, 6)]:
    q = {**p, "betaC": p["betaC"] * Rt / base_rc}
    found = None
    for guess in ([z] if z is not None else []) + [None, np.log(np.full(NA * NQ, 1e-4)), np.log(np.full(NA * NQ, 1e-2))]:
        x, zz, res, ok = foi_equilibrium(q, "covid", guess)
        if ok and res < 1e-12 and covid_inf(x) > 1e-12:
            found = (x, zz); break
    if found:
        x, z = found; prev = covid_inf(x)
        ev = np.linalg.eigvals(jac_alive(x, q, comps=COVID_ONLY_COMPS)).real.max()
    else:
        prev, ev = 0.0, np.nan
    evd = np.linalg.eigvals(jac_alive(dfe(q), q, comps=COVID_ONLY_COMPS)).real.max()
    bif_c.append([float(Rt), prev, float(ev), float(evd)])
out["bif_covid"] = bif_c
base_rh = R_H(p)[0]; bif_h = []; z = None
for Rt in np.r_[np.linspace(1.6, 1.002, 40), np.linspace(1.0, 0.8, 5)]:
    q = {**p, "betaH": p["betaH"] * Rt / base_rh}
    x, zz = hiv_equilibrium(q, z)
    if zz is not None:
        z = zz; prev = adult_prev(x)
        ev = np.linalg.eigvals(jac_alive(x, q, comps=HIV_ONLY_COMPS)).real.max()
    else:
        prev, ev = 0.0, np.nan
    evd = np.linalg.eigvals(jac_alive(dfe(q), q, comps=HIV_ONLY_COMPS)).real.max()
    bif_h.append([float(Rt), prev, float(ev), float(evd)])
out["bif_hiv"] = bif_h
out["bif_checks"] = {
    "covid_endemic_below_1": int(sum(1 for r in bif_c if r[0] < 1 and r[1] > 0)),
    "hiv_endemic_below_1": int(sum(1 for r in bif_h if r[0] < 1 and r[1] > 0)),
    "covid_endemic_max_abscissa": float(np.nanmax([r[2] for r in bif_c])),
    "hiv_endemic_max_abscissa": float(np.nanmax([r[2] for r in bif_h]))}
json.dump(out, open("results/B_thresholds.json", "w"))
print({k: v for k, v in out.items() if not isinstance(v, (dict, list))}, out["bif_checks"])
