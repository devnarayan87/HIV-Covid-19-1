"""Policy scenarios after an immune-escape wave (library used by analysis_C and the
uncertainty/robustness analyses)."""
import numpy as np
import jax, jax.numpy as jnp
from scipy.optimize import brentq
from model import *
from repro import *
from repro import _pc

T_HOR, DT = 730.0, 0.5
NSTEP = int(T_HOR / DT)
TGRID = np.arange(NSTEP + 1) * DT
CAMPAIGN = 120.0
DISRUPT = 180.0
PLW = ["L", "T", "U", "LR", "TR", "UR", "CL", "CU", "CT"]
POS = {"vac": slice(0, 4), "art": 4, "prev": 5, "iso": 6, "care": 7}


@jax.jit
def simulate(x0, Us, q):
    return rk4_path(x0, Us, q, DT)


def controls(**kw):
    U = np.zeros((NSTEP, NCTRL)); t = np.arange(NSTEP) * DT
    for k, (lev, tend) in kw.items():
        U[t < tend, POS[k]] = lev
    return jnp.asarray(U)


@jax.jit
def _fluxes(xs, Us, q):
    def one(x, u):
        lamC, lamH, N = forces(x, u, q)
        vac, vacP, tau, tauU, xi, care = rates(q, u)
        doses = vac * x[IDX["S"]] + vacP * (x[IDX["L"]] + x[IDX["T"]] + x[IDX["U"]])
        dCL, dCU, dCT = co_death_rates(q)
        dpl = care * (dCL * x[IDX["CL"]] + dCU * x[IDX["CU"]] + dCT * x[IDX["CT"]])
        dneg = care * q["dH"] * x[IDX["H"]]
        inf_pl = lamC * (x[IDX["L"]] + x[IDX["T"]] + x[IDX["U"]]) + (1 - q["epsP"]) * lamC * (
            x[IDX["LR"]] + x[IDX["TR"]] + x[IDX["UR"]])
        inf_neg = lamC * (x[IDX["S"]] + (1 - q["epsV"]) * x[IDX["V"]])
        return jnp.stack([doses, inf_pl, inf_neg, dpl, dneg, x[IDX["H"]]])
    Uext = jnp.concatenate([Us, Us[-1:]], axis=0)
    F = jax.vmap(one)(xs, Uext)
    tot = DT * (0.5 * F[0] + F[1:-1].sum(0) + 0.5 * F[-1])
    return tot, F[:, 5].sum(1)


def summarise(xs, Us, q, x0):
    tot, Hocc = _fluxes(xs, Us, _pc(q))
    doses, inf_pl, inf_neg, dpl, dneg, _ = [np.asarray(v) for v in tot]
    Hocc = np.asarray(Hocc); xT = np.asarray(xs[-1]); N0 = np.asarray(q["N0"])
    plw = np.asarray(sum(x0[IDX[k]] for k in PLW))
    o = {}
    o["covid_deaths_per100k"] = float(1e5 * xT[IDX["Dcov"]].sum())
    o["covid_deaths_PLHIV_per100k_PLHIV"] = float(1e5 * dpl.sum() / plw.sum())
    o["covid_deaths_HIVneg_per100k"] = float(1e5 * dneg.sum() / (N0.sum() - plw.sum()))
    o["covid_infections_per100k"] = float(1e5 * (inf_pl.sum() + inf_neg.sum()))
    o["peak_hosp_per100k"] = float(1e5 * Hocc.max())
    o["peak_day"] = float(TGRID[Hocc.argmax()])
    o["new_hiv_per100k"] = float(1e5 * xT[IDX["IncH"]].sum())
    o["aids_deaths_per100k"] = float(1e5 * xT[IDX["Dhiv"]].sum())
    o["doses_per100k"] = float(1e5 * doses.sum())
    agew = np.asarray(q["age_share"]); m = np.arange(NA) > 0
    ifr_pl = dpl.reshape(NA, -1).sum(1) / np.maximum(inf_pl.reshape(NA, -1).sum(1), 1e-30)
    ifr_ng = dneg.reshape(NA, -1).sum(1) / np.maximum(inf_neg.reshape(NA, -1).sum(1), 1e-30)
    o["IFR_ratio_PLHIV_agestd"] = float((agew[m] * ifr_pl[m]).sum() / (agew[m] * ifr_ng[m]).sum())
    dqa = xT[IDX["Dcov"]].reshape(NA, NQ, NR).sum(2); nqa = N0.reshape(NA, NQ, NR).sum(2)
    rate = (agew[:, None] * dqa / nqa).sum(0)
    o["mort_by_quartile_agestd_per100k"] = (1e5 * rate).tolist()
    o["RR_Q1_Q4"] = float(rate[0] / rate[-1])
    o["gap_Q1_Q4_per100k"] = float(1e5 * (rate[0] - rate[-1]))
    ranks = (np.arange(NQ) + 0.5) / NQ
    o["concentration_index"] = float(2 * np.cov(rate, ranks, bias=True)[0, 1] / rate.mean())
    o["mort_by_age_per100k"] = (1e5 * xT[IDX["Dcov"]].reshape(NA, -1).sum(1) / N0.reshape(NA, -1).sum(1)).tolist()
    return o, Hocc


def run_scenario(x0, q, U, disrupt=None):
    if disrupt is None:
        return simulate(x0, U, _pc(q))
    k = int(DISRUPT / DT)
    qd = {**q, "art_disrupt": disrupt[0], "xi_mult": disrupt[1]}
    xa = simulate(x0, U[:k], _pc(qd))
    xb = simulate(xa[-1], U[k:], _pc(q))
    return jnp.concatenate([xa, xb[1:]], axis=0)


def _match_doses(x0, q, U, w, budget, lo, hi):
    def f(s):
        qq = {**q, "vac_w": jnp.asarray(w * s)}
        return summarise(simulate(x0, U, _pc(qq)), U, qq, x0)[0]["doses_per100k"] - budget
    # bracket: start at lo and expand geometrically (keeps RK4 well inside its stability region)
    a, fa = lo, f(lo)
    if fa > 0:
        raise ValueError("lower scale already exceeds the dose budget")
    b = a
    while True:
        b = b * 1.6
        fb = f(b)
        if not np.isfinite(fb) or b > hi:
            raise ValueError("could not bracket the dose budget")
        if fb > 0:
            break
        a = b
    s = brentq(f, a, b, rtol=1e-7)
    return {**q, "vac_w": jnp.asarray(w * s)}


def all_scenarios(p, xE, chi=0.5, keep_traj=False):
    """Runs S0-S11. Vaccination scenarios S3-S8 use the dose budget of S3."""
    x0 = immune_escape(xE, chi)
    res = {}; traj = None
    U0n = controls()
    xs = run_scenario(x0, p, U0n)
    res["S0"], _ = summarise(xs, U0n, p, x0)
    if keep_traj:
        sel = slice(0, NSTEP + 1, 4)
        traj = {"t": TGRID[sel].tolist(),
                "H": (1e5 * np.asarray(xs[sel, IDX["H"]].sum(1))).tolist(),
                "C": (1e5 * np.asarray((xs[sel, IDX["CL"]] + xs[sel, IDX["CU"]] + xs[sel, IDX["CT"]]).sum(1))).tolist(),
                "I": (1e5 * np.asarray(sum(xs[sel, IDX[k]] for k in ["E", "EV", "A", "I"]).sum(1))).tolist()}
    res["S1"], _ = summarise(run_scenario(x0, p, U0n, disrupt=(0.5, 2.0)), U0n, p, x0)
    U = controls(art=(1.0, T_HOR)); res["S2"], _ = summarise(run_scenario(x0, p, U), U, p, x0)
    Uv = controls(vac=(0.5, CAMPAIGN))
    res["S3"], _ = summarise(run_scenario(x0, p, Uv), Uv, p, x0)
    budget = res["S3"]["doses_per100k"]
    A = np.repeat(np.arange(NA), NQ * NR)
    dep = np.array([2.0, 1.4, 0.8, 0.4])[QIDX]
    q4 = _match_doses(x0, p, Uv, np.where(A == 4, 1.0, 0.05), budget, 1e-2, 200.0)
    q5 = _match_doses(x0, {**p, "plhiv_vac_mult": 10.0}, Uv, np.ones(G), budget, 0.1, 5.0)
    q6 = _match_doses(x0, p, Uv, dep, budget, 1e-2, 200.0)
    w7 = np.where(A == 4, 1.0, 0.1) * dep
    q7 = _match_doses(x0, p, Uv, w7, budget, 1e-2, 200.0)
    q8 = _match_doses(x0, {**p, "plhiv_vac_mult": 10.0}, Uv, w7, budget, 1e-2, 200.0)
    for key, q in [("S4", q4), ("S5", q5), ("S6", q6), ("S7", q7), ("S8", q8)]:
        res[key], _ = summarise(run_scenario(x0, q, Uv), Uv, q, x0)
    U = controls(iso=(0.5, CAMPAIGN)); res["S9"], _ = summarise(run_scenario(x0, p, U), U, p, x0)
    U = controls(care=(1.0, T_HOR)); res["S10"], _ = summarise(run_scenario(x0, p, U), U, p, x0)
    U = controls(vac=(0.5, CAMPAIGN), iso=(0.5, CAMPAIGN), care=(1.0, T_HOR), art=(1.0, T_HOR))
    res["S11"], _ = summarise(run_scenario(x0, q8, U), U, q8, x0)
    base = res["S0"]
    for k, v in res.items():
        v["covid_deaths_averted_per100k"] = base["covid_deaths_per100k"] - v["covid_deaths_per100k"]
        v["plhiv_deaths_averted_per100k_PLHIV"] = base["covid_deaths_PLHIV_per100k_PLHIV"] - v["covid_deaths_PLHIV_per100k_PLHIV"]
        extra = v["doses_per100k"] - base["doses_per100k"]
        v["extra_doses_per100k"] = extra
        v["deaths_averted_per_1000_extra_doses"] = (1000 * v["covid_deaths_averted_per100k"] / extra) if extra > 1 else None
    return res, traj


NAMES_SC = {"S0": "Status quo", "S1": "HIV-service disruption (6 months)", "S2": "Rapid ART scale-up",
            "S3": "Vaccination, uniform", "S4": "Vaccination, age 60+ first",
            "S5": "Vaccination, PLHIV prioritised", "S6": "Vaccination, deprivation-weighted",
            "S7": "Vaccination, proportionate universalism", "S8": "Proportionate universalism + PLHIV",
            "S9": "Test-and-isolate (120 days)", "S10": "Enhanced clinical care",
            "S11": "Integrated syndemic package"}
