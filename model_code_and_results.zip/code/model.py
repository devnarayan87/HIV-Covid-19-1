"""
Age x deprivation x sexual-risk stratified HIV--SARS-CoV-2 co-infection model.

The model is written once in "production--destruction" form
    dx/dt = P(x,u) - Q(x,u) * x          (P >= 0, Q >= 0 elementwise)
so that the ODE right-hand side, the NSFD scheme and the adjoint system are
all generated from the same code (no transcription errors between them).

Units: time in days; state variables are population fractions (sum = 1 at t=0).
"""
import numpy as np
import jax
import jax.numpy as jnp

jax.config.update("jax_enable_x64", True)

# ------------------------------------------------------------------ strata
NA, NQ, NR = 5, 4, 2            # age groups, deprivation quartiles, sexual-risk groups
G = NA * NQ * NR                # number of strata
AGE_LABELS = ["0-14", "15-29", "30-44", "45-59", "60+"]
SES_LABELS = ["Q1 (most deprived)", "Q2", "Q3", "Q4 (least deprived)"]
RISK_LABELS = ["lower-risk", "key populations"]

# compartments (index into first axis of the state array)
NAMES = ["S", "V", "E", "EV", "A", "I", "H", "R",
         "L", "T", "U", "LR", "TR", "UR", "CL", "CU", "CT",
         "Dcov", "Dhiv", "IncH", "IncC"]
IDX = {n: k for k, n in enumerate(NAMES)}
NALIVE = 17                     # S..CT are alive compartments
NX = len(NAMES)

NCTRL = 8   # u1 (vaccination, one per deprivation quartile Q1..Q4), u2 ART, u3 HIV prevention, u4 test&isolate, u5 enhanced care
QIDX = np.array([(g // NR) % NQ for g in range(G)])


def stratum_index(a, q, r):
    return (a * NQ + q) * NR + r


def unflat(v):
    """(G,) -> (NA,NQ,NR)"""
    return v.reshape(NA, NQ, NR)


# ------------------------------------------------------------------ parameters
YR = 365.0   # all rates are per day; durations quoted in years are converted with YR


def primitive_parameters():
    """Primitive (input) parameters. Everything stratified is built by derive().
    Units: rates per day, durations in days, probabilities dimensionless."""
    p = {}
    # demography
    p["ses_share"] = np.full(NQ, 0.25)
    p["kp_age"] = np.array([0.0, 0.030, 0.025, 0.015, 0.005])   # target KP share by age (within-age turnover)
    p["kp_ses"] = np.array([1.40, 1.10, 0.85, 0.65])            # relative KP share by quartile
    p["mu_age"] = np.array([0.0015, 0.0012, 0.0025, 0.0080, 1 / 17.0]) / YR
    p["alpha_age"] = np.array([1 / 15, 1 / 15, 1 / 15, 1 / 15, 0.0]) / YR
    p["kp_out"] = 1 / (7 * YR)
    # SARS-CoV-2 natural history
    p["sigma"] = 1 / 3.0
    p["rho"] = 0.40                      # asymptomatic fraction (p_a in the paper)
    p["gamma"] = 1 / 7.0
    p["iota1"] = 0.55
    p["iotaC"] = 0.85
    p["hosp_p"] = np.array([0.0003, 0.0006, 0.0015, 0.004, 0.015])
    p["hosp_mult"] = 1.0
    p["LOS"] = 9.0
    p["fH"] = np.array([0.005, 0.010, 0.030, 0.060, 0.120])
    p["fH_mult"] = 1.0
    p["HR_L"], p["HR_U"], p["HR_T"] = 1.6, 3.0, 1.3
    p["gCL"], p["gCU"], p["gCT"] = 1 / 9.0, 1 / 14.0, 1 / 8.0
    p["epsV"] = 0.50
    p["epsSev"] = 0.70
    p["epsP"] = 0.60
    p["eta"] = 1 / 180.0                 # vaccine waning
    p["eps"] = 1 / 240.0                 # waning of infection-derived immunity (zeta in the paper)
    p["epsPw"] = 1 / 210.0               # waning of protection among PLHIV (varpi in the paper)
    p["nu0"] = 1e-4
    # deprivation gradients (base shapes; g_* scale their strength, 1 = baseline, 0 = no gradient)
    p["crowd_base"] = np.array([1.20, 1.07, 0.95, 0.85])
    p["vacacc_base"] = np.array([0.75, 0.90, 1.05, 1.30])
    p["artacc_base"] = np.array([0.80, 0.93, 1.05, 1.20])
    p["fatal_base"] = np.array([1.25, 1.10, 0.95, 0.80])
    p["g_crowd"] = p["g_vac"] = p["g_art"] = p["g_fatal"] = 1.0
    # COVID contacts (contacts/day; row = respondent age) and between-quartile assortativity
    p["c_raw"] = np.array([[7.0, 2.5, 2.5, 1.2, 0.6],
                           [2.3, 6.0, 3.0, 1.8, 0.7],
                           [2.6, 3.2, 4.5, 2.2, 0.9],
                           [1.8, 2.8, 3.2, 3.0, 1.2],
                           [1.5, 1.8, 2.2, 2.0, 2.0]])
    p["assort_C"] = 0.5
    p["betaC"] = 0.05
    # HIV
    p["omega"] = 1 / (9 * YR)
    p["muU"] = 1 / (1.5 * YR)
    p["muT"] = 0.004 / YR
    p["xi"] = 1 / (8 * YR)
    p["tau"] = 1 / (2.5 * YR)
    p["tauU_mult"] = 2.0
    p["kappaU"] = 1.3
    p["epsT"] = 0.01                     # residual infectivity on ART (kappa_T in the paper)
    p["theta"] = 1.0
    p["act_age"] = np.array([0.0, 1.0, 0.8, 0.5, 0.2])
    p["act_lo"] = 0.2 / YR               # partnerships per day, lower-risk
    p["c_high"] = 10.0                   # partnerships per year, key populations
    p["eps_age"], p["eps_ses"], p["eps_risk"] = 0.7, 0.5, 0.8
    p["betaH"] = 0.05
    # controls
    p["vmax"] = 0.004
    p["tau_max"] = 1 / 90.0
    p["prev_max"] = 0.6
    p["iso_eff"] = 0.8
    p["iso_max"] = 0.4
    p["psi"] = 0.30
    p["plhiv_vac_mult"] = 1.0
    p["vac_w"] = np.ones(G)
    p["art_disrupt"] = 1.0
    p["xi_mult"] = 1.0
    return p


def grad(base, g):
    """Deprivation gradient of strength g around 1 (g=0: flat, g=1: baseline shape)."""
    return 1.0 + g * (np.asarray(base) - 1.0)


def derive(p):
    """Build all stratified/derived quantities from primitive parameters.
    Returns a new dict with jnp arrays (the model's parameter pytree)."""
    p = {k: (np.asarray(v) if isinstance(v, (np.ndarray, jnp.ndarray)) else v) for k, v in p.items()}
    q = dict(p)
    # ---- demography
    sh = p["kp_age"][:, None] * p["kp_ses"][None, :]
    q["mu"] = np.repeat(p["mu_age"], NQ * NR)
    q["alpha"] = p["alpha_age"]
    kp_in = np.zeros((NA, NQ)); kp_in[1:] = p["kp_out"] * sh[1:] / (1 - sh[1:])
    q["kp_in"] = kp_in
    q["sh1"] = sh[1]
    births = np.zeros((NA, NQ, NR)); births[0, :, 0] = p["ses_share"]
    Pf, Qf = demography_operator(np.eye(G), q, as_matrix=True)
    Mdem = Pf - np.diag(Qf + q["mu"])
    N0 = -np.linalg.solve(Mdem, births.reshape(G))
    B = 1.0 / N0.sum()
    q["N0"] = N0 * B
    q["Lambda"] = births.reshape(G) * B
    q["age_share"] = q["N0"].reshape(NA, NQ, NR).sum(axis=(1, 2))
    # ---- SARS-CoV-2 severity
    hosp = np.clip(p["hosp_p"] * p["hosp_mult"], 0, 0.5)
    q["hosp_eff"] = hosp
    q["delta"] = np.repeat(p["gamma"] * hosp / (1 - hosp), NQ * NR)
    fat = grad(p["fatal_base"], p["g_fatal"])
    fH_g = np.clip(p["fH"][:, None, None] * p["fH_mult"] * fat[None, :, None] * np.ones((NA, NQ, NR)), 0, 0.9).reshape(G)
    q["dH"] = fH_g / p["LOS"]
    q["gH"] = (1 - fH_g) / p["LOS"]
    q["vac_access"] = (grad(p["vacacc_base"], p["g_vac"])[None, :, None] * np.ones((NA, NQ, NR))).reshape(G)
    q["art_access"] = (grad(p["artacc_base"], p["g_art"])[None, :, None] * np.ones((NA, NQ, NR))).reshape(G)
    # ---- COVID contact operator M^C (reciprocal in age, symmetric in quartile)
    Na = q["age_share"]; c = p["c_raw"]
    csym = (c * Na[:, None] + (c * Na[:, None]).T) / (2 * Na[:, None])
    q["Cage"] = csym
    m_ses = p["assort_C"] * np.eye(NQ) + (1 - p["assort_C"]) * p["ses_share"][None, :]
    h = grad(p["crowd_base"], p["g_crowd"])
    K = (csym[:, None, :, None] * m_ses[None, :, None, :]
         * np.sqrt(h[None, :, None, None] * h[None, None, None, :]))
    q["K"] = K.reshape(NA * NQ, NA * NQ)
    # ---- sexual partnerships: raw rates, preferential mixing, then balancing
    c_raw = (p["act_age"][:, None, None] * np.ones((NA, NQ, NR))
             * np.array([p["act_lo"], p["c_high"] / YR])[None, None, :]).reshape(G)
    c_bal, M_bal = balanced_sexual_mixing(q["N0"], c_raw, p["eps_age"], p["eps_ses"], p["eps_risk"])
    q["c_raw_sex"] = c_raw
    q["c_sex"] = c_bal
    q["Msex"] = M_bal
    return {k: (jnp.asarray(v) if isinstance(v, np.ndarray) else v) for k, v in q.items()}


def baseline_parameters():
    return derive(primitive_parameters())


def balanced_sexual_mixing(N0, c, ea, es, er):
    """Separable preferential mixing (Garnett--Anderson) over age, deprivation and risk,
    followed by symmetrisation of the partnership matrix so that the number of
    partnerships g->h equals h->g (partnership balance).
    Returns balanced partnership rates c_bal (per day) and M[g,h] (rows sum to 1)."""
    N0 = np.asarray(N0); c = np.asarray(c)
    supply = (c * N0).reshape(NA, NQ, NR)
    sa = supply.sum(axis=(1, 2)); sq = supply.sum(axis=(0, 2)); sr = supply.sum(axis=(0, 1))
    Ma = ea * np.eye(NA) + (1 - ea) * (sa / sa.sum())[None, :]
    Mq = es * np.eye(NQ) + (1 - es) * (sq / sq.sum())[None, :]
    Mr = er * np.eye(NR) + (1 - er) * (sr / sr.sum())[None, :]
    Ma[:, 0] = 0.0                                   # no partnerships with children
    Ma = Ma / Ma.sum(axis=1, keepdims=True)
    Mraw = np.einsum("ab,qs,rt->aqrbst", Ma, Mq, Mr).reshape(G, G)
    Z = (c * N0)[:, None] * Mraw                     # partnerships formed by g with h
    Zb = 0.5 * (Z + Z.T)                             # balanced: Zb[g,h] = Zb[h,g]
    tot = Zb.sum(axis=1)
    c_bal = np.where(N0 > 0, tot / np.maximum(N0, 1e-300), 0.0)
    M = np.where(tot[:, None] > 0, Zb / np.maximum(tot[:, None], 1e-300), 0.0)
    return c_bal, M


# ------------------------------------------------------------------ dynamics
def forces(x, u, p):
    S, V, E, EV, A, I, H, R, L, T, U, LR, TR, UR, CL, CU, CT = [x[k] for k in range(NALIVE)]
    N = x[:NALIVE].sum(axis=0)
    # COVID: infectious pressure by (age, ses), pooled over risk
    J = I + p["iota1"] * A + p["iotaC"] * (CL + CU + CT)
    Jaq = J.reshape(NA * NQ, NR).sum(axis=1)
    Naq = N.reshape(NA * NQ, NR).sum(axis=1) + 1e-30
    lamC_aq = p["betaC"] * (1 - p["iso_eff"] * p["iso_max"] * u[6]) * (p["K"] @ (Jaq / Naq))
    lamC = jnp.repeat(lamC_aq, NR)
    # HIV
    Y = (L + LR) + p["kappaU"] * (U + UR) + p["epsT"] * (T + TR + CT) + p["theta"] * (CL + p["kappaU"] * CU)
    lamH = (1 - p["prev_max"] * u[5]) * p["betaH"] * p["c_sex"] * (p["Msex"] @ (Y / (N + 1e-30)))
    return lamC, lamH, N


def rates(p, u):
    # routine uptake follows the access gradient; campaign doses (u1) are allocated per capita
    vac = (p["nu0"] * p["vac_access"] + p["vmax"] * u[QIDX]) * p["vac_w"]
    vacP = vac * p["plhiv_vac_mult"]
    tau = (p["tau"] * p["art_disrupt"] + p["tau_max"] * u[4]) * p["art_access"]
    tauU = (p["tau"] * p["tauU_mult"] * p["art_disrupt"] + p["tau_max"] * u[4]) * p["art_access"]
    xi = p["xi"] * p["xi_mult"]
    care = 1 - p["psi"] * u[7]
    return vac, vacP, tau, tauU, xi, care


def co_death_rates(p):
    # infection fatality ratio among HIV-negative, by stratum
    hosp = jnp.repeat(jnp.asarray(p["hosp_eff"]), NQ * NR)
    ifr = (1 - p["rho"]) * hosp * (p["dH"] * p["LOS"])
    out = []
    for hr, g in [(p["HR_L"], p["gCL"]), (p["HR_U"], p["gCU"]), (p["HR_T"], p["gCT"])]:
        Pd = jnp.clip(hr * ifr, 0, 0.95)
        out.append(g * Pd / (1 - Pd))
    return tuple(out)


def demography_operator(X, p, as_matrix=False):
    """Ageing and key-population turnover for a stack of compartments X (..., G).
    Returns inflow P (..., G) and per-capita outflow rate Q (G,).
    With as_matrix=True and X = I, P is the (G x G) inflow matrix."""
    xp = np if as_matrix else jnp
    al = xp.asarray(p["alpha"]); kin = xp.asarray(p["kp_in"]); kout = p["kp_out"]; sh1 = xp.asarray(p["sh1"])
    lead = X.shape[:-1]
    Xr = X.reshape(lead + (NA, NQ, NR))
    zero = xp.zeros(lead + (1, NQ, NR))
    # ageing inflow: groups 2..4 keep risk group; group 1 (15-29) receives children split by sh1
    agein = Xr[..., :-1, :, :] * al[:-1][:, None, None]
    child = agein[..., 0, :, :].sum(axis=-1)                        # (..., NQ)
    first = xp.stack([child * (1 - sh1), child * sh1], axis=-1)[..., None, :, :]
    rest = agein[..., 1:, :, :]
    Pin = xp.concatenate([zero, first, rest], axis=-3)
    # key-population turnover within (age, ses)
    lo, hi = Xr[..., 0], Xr[..., 1]
    turn = xp.stack([kout * hi, kin * lo], axis=-1) * (xp.arange(NA) > 0)[:, None, None]
    Pin = Pin + turn
    Qr = (al[:, None, None] * xp.ones((NA, NQ, NR))
          + xp.stack([kin, kout * xp.ones((NA, NQ))], axis=-1) * (xp.arange(NA) > 0)[:, None, None])
    P = Pin.reshape(lead + (G,))
    Q = Qr.reshape(G)
    if as_matrix:
        P = P.T          # P[g, h] = rate of flow from h into g
    return P, Q


def PQ(x, u, p, lam=None):
    """Production vector P (NX,G) >= 0 and per-capita destruction Q (NX,G) >= 0.
    If lam=(lamC, lamH) is given the forces of infection are held fixed (used to
    compute equilibria by a fixed point in the forces of infection)."""
    S, V, E, EV, A, I, H, R, L, T, U, LR, TR, UR, CL, CU, CT = [x[k] for k in range(NALIVE)]
    if lam is None:
        lamC, lamH, N = forces(x, u, p)
    else:
        lamC, lamH = lam
    vac, vacP, tau, tauU, xi, care = rates(p, u)
    mu = p["mu"]; s, rho, g = p["sigma"], p["rho"], p["gamma"]
    rhoV = 1 - (1 - rho) * (1 - p["epsSev"])          # asymptomatic fraction of breakthrough infections
    eV, eP, om = p["epsV"], p["epsP"], p["omega"]
    dCL, dCU, dCT = co_death_rates(p)
    dH = p["dH"] * care; dCL = dCL * care; dCU = dCU * care; dCT = dCT * care
    w = p["epsPw"]
    z = jnp.zeros_like(S)
    P = jnp.stack([
        p["Lambda"] + p["eta"] * V + p["eps"] * R,                               # S
        vac * S,                                                                 # V
        lamC * S,                                                                # E
        (1 - eV) * lamC * V,                                                     # EV (breakthrough)
        rho * s * E + rhoV * s * EV,                                             # A
        (1 - rho) * s * E + (1 - rhoV) * s * EV,                                 # I
        p["delta"] * I,                                                          # H
        g * (A + I) + p["gH"] * H,                                               # R
        lamH * S + xi * T + w * LR,                                              # L
        tau * L + tauU * U + w * TR,                                             # T
        om * L + w * UR,                                                         # U
        lamH * (V + R) + vacP * L + p["gCL"] * CL + xi * TR,                     # LR
        vacP * T + p["gCT"] * CT + tau * LR + tauU * UR,                         # TR
        vacP * U + om * LR + p["gCU"] * CU,                                      # UR
        lamC * L + (1 - eP) * lamC * LR + lamH * (E + EV + A + I) + xi * CT,          # CL
        lamC * U + (1 - eP) * lamC * UR + om * CL,                               # CU
        lamC * T + (1 - eP) * lamC * TR + tau * CL + tauU * CU,                  # CT
        dH * H + dCL * CL + dCU * CU + dCT * CT,                                 # Dcov
        p["muU"] * (U + UR + CU) + p["muT"] * (T + TR + CT),                     # Dhiv
        lamH * (S + V + R + E + EV + A + I),                                          # IncH
        lamC * (S + (1 - eV) * V + L + T + U + (1 - eP) * (LR + TR + UR)),        # IncC
    ])
    Q = jnp.stack([
        lamC + lamH + vac + mu,                                                  # S
        (1 - eV) * lamC + lamH + p["eta"] + mu,                                  # V
        s + lamH + mu,                                                           # E
        s + lamH + mu,                                                           # EV
        g + lamH + mu,                                                           # A
        g + p["delta"] + lamH + mu,                                              # I
        p["gH"] + dH + mu,                                                       # H
        p["eps"] + lamH + mu,                                                    # R
        lamC + tau + om + vacP + mu,                                             # L
        lamC + xi + vacP + mu + p["muT"],                                        # T
        lamC + tauU + vacP + mu + p["muU"],                                      # U
        (1 - eP) * lamC + tau + om + w + mu,                                     # LR
        (1 - eP) * lamC + xi + w + mu + p["muT"],                                # TR
        (1 - eP) * lamC + tauU + w + mu + p["muU"],                              # UR
        p["gCL"] + tau + om + dCL + mu,                                          # CL
        p["gCU"] + tauU + dCU + mu + p["muU"],                                   # CU
        p["gCT"] + xi + dCT + mu + p["muT"],                                     # CT
        z, z, z, z,
    ])
    Pd, Qd = demography_operator(x[:NALIVE], p)
    P = P.at[:NALIVE].add(Pd)
    Q = Q.at[:NALIVE].add(Qd[None, :])
    return P, Q


def rhs(x, u, p):
    P, Q = PQ(x, u, p)
    return P - Q * x


# ------------------------------------------------------------------ integrators
def rk4_path(x0, U, p, dt):
    """U: (nsteps, NCTRL) piecewise-constant controls. Returns states at nsteps+1 nodes."""
    def step(x, u):
        k1 = rhs(x, u, p)
        k2 = rhs(x + 0.5 * dt * k1, u, p)
        k3 = rhs(x + 0.5 * dt * k2, u, p)
        k4 = rhs(x + dt * k3, u, p)
        xn = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        return xn, xn
    _, xs = jax.lax.scan(step, x0, U)
    return jnp.concatenate([x0[None], xs], axis=0)


def nsfd_path(x0, U, p, h):
    """Mickens-type NSFD:  (x^{n+1}-x^n)/phi(h) = P(x^n) - Q(x^n) x^{n+1}."""
    mubar = jnp.max(p["mu"])
    phi = (1 - jnp.exp(-mubar * h)) / mubar
    def step(x, u):
        P, Q = PQ(x, u, p)
        xn = (x + phi * P) / (1 + phi * Q)
        return xn, xn
    _, xs = jax.lax.scan(step, x0, U)
    return jnp.concatenate([x0[None], xs], axis=0)


def euler_path(x0, U, p, h):
    def step(x, u):
        xn = x + h * rhs(x, u, p)
        return xn, xn
    _, xs = jax.lax.scan(step, x0, U)
    return jnp.concatenate([x0[None], xs], axis=0)


# ------------------------------------------------------------------ helpers
def empty_state(p):
    x = jnp.zeros((NX, G))
    return x.at[IDX["S"]].set(p["N0"])


def alive(x):
    return x[:NALIVE].sum(axis=0)


def plhiv(x):
    return sum(x[IDX[k]] for k in ["L", "T", "U", "LR", "TR", "UR", "CL", "CU", "CT"])


def on_art(x):
    return sum(x[IDX[k]] for k in ["T", "TR", "CT"])
