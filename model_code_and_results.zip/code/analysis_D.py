"""NSFD verification (results/D_nsfd.json):
(i) positivity from random non-negative states with random controls for h up to 1000 days;
(ii) exact preservation of the DFE, HIV-only, COVID-only and coexistence equilibria for any h;
(iii) convergence order against a fine RK4 reference; comparison with explicit Euler and RK4,
including their failure at large steps."""
import json
import numpy as np
import jax, jax.numpy as jnp
from common import *

p = P(); xH, xE, zH, zE = equilibria()
xC, _, _, _ = foi_equilibrium(p, "covid")
x0 = immune_escape(xE, chi=0.5)
rng = np.random.default_rng(11)
out = {}
# (i) positivity
pos = []
for h in [0.1, 1.0, 10.0, 100.0, 1000.0]:
    mins = []
    for trial in range(10):
        x = jnp.asarray(rng.random((NX, G)) * rng.choice([1e-8, 1e-3, 1.0], size=(NX, G)))
        Us = jnp.asarray(rng.random((50, NCTRL)))
        xs = jax.jit(nsfd_path)(x, Us, p, h)
        mins.append(float(jnp.min(xs)))
    pos.append({"h": h, "min_state": min(mins)})
out["positivity"] = pos
print("positivity", pos)
# (ii) equilibria are fixed points for every h
fp = []
for name, xe in [("DFE", dfe(p)), ("HIV-only", xH), ("COVID-only", xC), ("coexistence", xE)]:
    for h in [0.5, 5.0, 50.0, 500.0]:
        xs = jax.jit(nsfd_path)(xe, jnp.zeros((20, NCTRL)), p, h)
        a = xs[-1, :NALIVE]; b = xe[:NALIVE]
        rel = float(jnp.max(jnp.abs(a - b) / (jnp.abs(b) + 1e-300) * (jnp.abs(b) > 1e-20)))
        fp.append({"eq": name, "h": h, "max_rel_drift": rel})
out["fixed_points"] = fp
print("fixed points max drift", max(r["max_rel_drift"] for r in fp))
# (iii) convergence
T = 360.0
def path(scheme, h):
    n = int(round(T / h)); Us = jnp.zeros((n, NCTRL))
    f = {"nsfd": nsfd_path, "rk4": rk4_path, "euler": euler_path}[scheme]
    return jax.jit(f)(x0, Us, p, h)
def qoi(xs, h, every=4.0):
    k = int(round(every / h)); xs = xs[::k]
    return np.asarray(sum(xs[:, IDX[c]] for c in ["E", "EV", "A", "I"]).sum(1)), np.asarray(xs[:, IDX["Dcov"]].sum(1))
ref = path("rk4", 0.01); inf_ref, D_ref = qoi(ref, 0.01)
conv = []
for h in [4.0, 2.0, 1.0, 0.5, 0.25, 0.125, 0.0625]:
    row = {"h": h}
    for sch in ["nsfd", "euler", "rk4"]:
        xs = np.asarray(path(sch, h))
        if np.isfinite(xs).all():
            inf, D = qoi(xs, h)
            row[sch + "_err_inf"] = float(np.max(np.abs(inf - inf_ref)) / np.max(inf_ref))
            row[sch + "_err_D"] = float(abs(D[-1] - D_ref[-1]) / D_ref[-1])
            row[sch + "_min"] = float(xs[:, :NALIVE].min())
        else:
            row[sch + "_err_inf"] = row[sch + "_err_D"] = row[sch + "_min"] = float("nan")
    conv.append(row); print(row)
out["convergence"] = conv
hs = np.array([r["h"] for r in conv])
for sch, sel in [("nsfd", hs <= 1.0), ("euler", hs <= 1.0), ("rk4", (hs <= 1.0) & (hs >= 0.125))]:
    e = np.array([r[sch + "_err_inf"] for r in conv])
    out[sch + "_order"] = float(np.polyfit(np.log(hs[sel]), np.log(e[sel]), 1)[0])
big = []
for h in [6.0, 10.0, 20.0, 30.0]:
    r = {"h": h}
    for sch in ["nsfd", "euler", "rk4"]:
        xs = np.asarray(path(sch, h))
        r[sch] = "blow-up" if not np.isfinite(xs).all() else float(xs[:, :NALIVE].min())
    big.append(r)
out["large_step"] = big
print("orders", out["nsfd_order"], out["euler_order"], out["rk4_order"], big)
json.dump(out, open("results/D_nsfd.json", "w"), indent=1)
