"""Shared loaders for the analysis scripts."""
import json, os
import numpy as np
import jax, jax.numpy as jnp
from model import *
from repro import *

HERE = os.path.dirname(os.path.abspath(__file__))


def load_primitive():
    d = json.load(open(os.path.join(HERE, "results", "calibrated_primitive.json")))
    return {k: (np.array(v) if isinstance(v, list) else v) for k, v in d.items()}


def P():
    """Calibrated (derived) parameter set."""
    return derive(load_primitive())


def equilibria():
    d = np.load(os.path.join(HERE, "results", "equilibria.npz"))
    return jnp.asarray(d["xH"]), jnp.asarray(d["xE"]), d["zH"], d["zE"]
