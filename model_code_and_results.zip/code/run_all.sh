#!/usr/bin/env bash
# Regenerates every result, figure and number in the manuscript.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p results logs
run() { echo "== $1"; python3 -u "$1".py > "logs/$1.txt" 2>&1; }
run calibrate
run verify_math
run gas_bound
run analysis_A
run analysis_C
run analysis_D
run analysis_B
run analysis_F
run robustness
if [[ "${1:-}" == "--ensemble" ]]; then
  W="${2:-2}"
  for i in $(seq 1 "$W"); do python3 -u uncertainty.py worker > "logs/ensemble_w$i.txt" 2>&1 & done
  wait
  python3 -u uncertainty.py summarise > logs/ensemble_summary.txt 2>&1
fi
python3 -u figs2.py
python3 -u make_numbers2.py
echo "done: build the paper with  cd manuscript && pdflatex manuscript && bibtex manuscript && pdflatex manuscript && pdflatex manuscript"
