# HIV–SARS-CoV-2 syndemic model: code for "Threshold dynamics and equity-weighted control of HIV–SARS-CoV-2 co-infection in a deprivation- and risk-stratified population"

This repository regenerates every number, table and figure in the manuscript.

## Requirements

Python 3.11 or later (tested with 3.13.16) and the pinned packages in `requirements.txt`:

```
pip install -r requirements.txt
```

All computations run on a CPU in double precision (`jax_enable_x64`). A LaTeX distribution (`pdflatex`, `bibtex`) is needed only to build the manuscript.

## One-command reproduction

```
bash run_all.sh            # calibration, verification, analyses, figures, numbers
bash run_all.sh --ensemble 4   # additionally run the 160-member uncertainty ensemble with 4 workers
```

| Step | Script | Output | Time on 1 CPU core |
|---|---|---|---|
| Calibration | `calibrate.py` | `results/calibration.json`, `results/calibrated_primitive.json`, `results/equilibria.npz` | ~1 min |
| Mathematical verification (Table 4) | `verify_math.py` | `results/verify_math.json` | ~3 min |
| Global-stability quantities | `gas_bound.py` | `results/H_gas.json` | <1 min |
| Thresholds, equilibria, spectra | `analysis_A.py` | `results/A_thresholds.json` | ~1 min |
| Threshold surfaces, bifurcation | `analysis_B.py` | `results/B_thresholds.json` | ~10 min |
| Policy scenarios | `analysis_C.py` | `results/C_scenarios.json` | <1 min |
| NSFD verification | `analysis_D.py` | `results/D_nsfd.json` | ~2 min |
| Optimal control and its verification | `analysis_F.py` | `results/F_control.json`, `results/F_controls.npz` | ~30 min |
| Structural robustness | `robustness.py` | `results/G_robustness.json` | ~20 min |
| Uncertainty ensemble | `uncertainty.py worker` (any number in parallel), then `uncertainty.py summarise` | `results/ensemble/`, `results/E_uncertainty.json` | ~1 min per member |
| Figures | `figs2.py` | `manuscript/Fig2.pdf` … `Fig10.pdf` (+ `.eps`) | <1 min |
| Numbers and tables in the text | `make_numbers2.py` | `manuscript/numbers.tex`, `manuscript/*_table.tex` | <1 min |

Every number quoted in the manuscript is a LaTeX macro defined in `manuscript/numbers.tex`, which `make_numbers2.py` writes from the JSON outputs. No numbers are typed by hand.

## Code structure

| File | Content |
|---|---|
| `model.py` | Parameters (`primitive_parameters`, `derive`), forces of infection, production–destruction form `PQ`, RK4, NSFD and Euler integrators |
| `repro.py` | Next-generation matrices, reproduction and invasion numbers, exact endemic equilibria (fixed point in log forces of infection) |
| `calibrate.py` | Calibration of β_C, β_H and τ₀ to the targets at the coexistence equilibrium |
| `scenarios.py` | Immune-escape wave and policy scenarios S0–S11 (equal-dose vaccine allocation) |
| `control.py` | Forward–backward sweep with exact discrete adjoint; L-BFGS-B cross-check |
| `common.py` | Loaders for calibrated parameters and equilibria |

## Correspondence between code and manuscript notation

| Code | Paper | Code | Paper |
|---|---|---|---|
| `rho` | p_a | `eps` | ζ (waning, infection) |
| `epsPw` | ϖ | `epsT` | κ_T |
| `epsV`, `epsP`, `epsSev` | ϵ_V, ϵ_P, ϵ_sev | `eps_age`, `eps_ses`, `eps_risk` | ς_age, ς_dep, ς_risk |
| `assort_C` | ς_C | `crowd_base` | χ_n |
| `K` | M^C | `Msex`, `c_sex` | M^H, c_g |
| `tauU_mult` | m_τ | `plhiv_vac_mult` | r_P |
| `vac_w` | ϑ_g | `chi` (scenarios) | f_esc |
| `EV`, `LR`, `TR`, `UR` | E^V, L^R, T^R, U^R | `CL`, `CU`, `CT` | C_L, C_U, C_T |

Units: time in days; all rates per day; state variables are fractions of the stationary population; outputs per 100 000.

## Data

All inputs are published aggregate estimates cited in the manuscript; no individual-level data are used.

## Licence and citation

[Licence to be chosen by the authors.] Please cite the article (details in `CITATION.cff` after publication).
