#!/usr/bin/env bash
# Builds the submission package and the code archive.
set -euo pipefail
cd "$(dirname "$0")"
OUT="${1:-dist}"
rm -rf "$OUT"; mkdir -p "$OUT/BMB_manuscript_source" "$OUT/code"
M=manuscript
( cd $M && pdflatex -interaction=nonstopmode manuscript >/dev/null && bibtex manuscript >/dev/null \
  && pdflatex -interaction=nonstopmode manuscript >/dev/null && pdflatex -interaction=nonstopmode manuscript >/dev/null \
  && pdflatex -interaction=nonstopmode cover_letter >/dev/null && pdflatex -interaction=nonstopmode revision_report >/dev/null \
  && pdflatex -interaction=nonstopmode revision_report >/dev/null )
cp $M/{manuscript.tex,body.tex,body_analysis.tex,results.tex,discussion.tex,abstract.tex,declarations.tex,appendix.tex,numbers.tex,scenario_table.tex,robust_table.tex,prcc_table.tex,refs.bib,manuscript.bbl,sn-jnl.cls,sn-basic.bst,Fig1.tex} "$OUT/BMB_manuscript_source/"
cp $M/Fig{1,2,3,4,5,6,7,8,9,10}.{pdf,eps} "$OUT/BMB_manuscript_source/"
cp $M/manuscript.pdf "$OUT/HIV_SARSCoV2_BMB_manuscript.pdf"
cp $M/cover_letter.pdf "$OUT/BMB_cover_letter.pdf"; cp $M/cover_letter.tex "$OUT/BMB_manuscript_source/"
cp $M/revision_report.pdf "$OUT/Revision_report_checklist.pdf"
for f in README.md requirements.txt run_all.sh package.sh model.py repro.py calibrate.py common.py scenarios.py control.py \
         verify_math.py gas_bound.py analysis_A.py analysis_B.py analysis_C.py analysis_D.py analysis_F.py robustness.py \
         uncertainty.py figs2.py make_numbers2.py; do cp "$f" "$OUT/code/"; done
mkdir -p "$OUT/code/results"; cp results/*.json results/*.npz "$OUT/code/results/"
cp -r results/ensemble "$OUT/code/results/"; rm -f "$OUT/code/results/ensemble/claim_"*
( cd "$OUT" && zip -qr BMB_manuscript_source.zip BMB_manuscript_source && zip -qr model_code_and_results.zip code )
echo "package written to $OUT"
