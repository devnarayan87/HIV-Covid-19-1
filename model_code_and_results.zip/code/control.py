"""Optimal control by the forward--backward sweep method (FBSM).

Forward sweep : RK4 integration of the state system with piecewise-constant controls.
Backward sweep: the *exact discrete adjoint* of that RK4 scheme, obtained by
                reverse-mode automatic differentiation (jax.vjp), i.e. the costate
                lambda_k satisfies the discrete analogue of  lambda' = -dH/dx.
Control update: Pontryagin characterisation u_j = min(1, max(0, -lambda^T f_{u_j} / B_j)),
                which is exact here because f is affine in each control and the running
                cost is quadratic in u; a convex relaxation is used between sweeps.
"""
import numpy as np
import jax
import jax.numpy as jnp
from model import *

QW_DEFAULT = np.ones(NQ)


def running_state_cost(x, u, p, W):
    """Running cost (per day), expressed per 100 000 population."""
    P, Q = PQ(x, u, p)
    covid_deaths = P[IDX["Dcov"]]
    aids_deaths = P[IDX["Dhiv"]]
    new_hiv = P[IDX["IncH"]]
    w_ses = jnp.asarray(W["ses_w"])[QIDX]
    return 1e5 * (W["death"] * jnp.sum(w_ses * (covid_deaths + aids_deaths))
                  + W["hiv"] * jnp.sum(w_ses * new_hiv)
                  + W["bed"] * jnp.sum(x[IDX["H"]]))


def make_problem(x0, p, W, B, dt, nsteps, active):
    """active: boolean mask (NCTRL,) of controls that may be used."""
    B = jnp.asarray(B); active = jnp.asarray(active, dtype=float)

    def f(x, u):
        return rhs(x, u, p)

    def state_cost(U):
        Ua = U * active
        def step(x, u):
            k1 = f(x, u); k2 = f(x + 0.5 * dt * k1, u)
            k3 = f(x + 0.5 * dt * k2, u); k4 = f(x + dt * k3, u)
            xn = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
            # trapezoidal quadrature of the running cost on each step
            c = 0.5 * dt * (running_state_cost(x, u, p, W) + running_state_cost(xn, u, p, W))
            return xn, c
        xT, cs = jax.lax.scan(step, x0, Ua)
        return jnp.sum(cs)

    def control_cost(U):
        return jnp.sum(0.5 * dt * (U * active) ** 2 * B[None, :])

    grad_state = jax.jit(jax.grad(state_cost))
    J_state = jax.jit(state_cost)
    return J_state, grad_state, control_cost


def fbsm(x0, p, W, B, T=730.0, dt=0.5, active=None, U0=None, relax=0.5, tol=1e-4,
         maxit=200, verbose=False):
    nsteps = int(round(T / dt))
    active = np.ones(NCTRL, bool) if active is None else np.asarray(active, bool)
    J_state, grad_state, control_cost = make_problem(x0, p, W, B, dt, nsteps, active)
    U = jnp.zeros((nsteps, NCTRL)) if U0 is None else jnp.asarray(U0)
    Bv = jnp.asarray(B)
    hist = []
    for it in range(maxit):
        g = grad_state(U)                      # = dt * lambda^T f_u (discrete adjoint)
        Unew = jnp.clip(-g / (dt * Bv[None, :]), 0.0, 1.0) * jnp.asarray(active, float)
        err = float(jnp.max(jnp.abs(Unew - U)) / (jnp.max(jnp.abs(Unew)) + 1e-12))
        U = relax * Unew + (1 - relax) * U
        Jtot = float(J_state(U) + control_cost(U))
        hist.append((it, Jtot, err))
        if verbose and it % 10 == 0:
            print(it, Jtot, err, flush=True)
        if err < tol:
            break
    return U, hist, float(J_state(U)), float(control_cost(U))


# ------------------------------------------------------------------ verification utilities
def total_objective(x0, p, W, B, dt, nsteps, active):
    """J(U) = discretised state cost + control cost, and its exact gradient."""
    J_state, grad_state, control_cost = make_problem(x0, p, W, B, dt, nsteps, active)
    Bv = jnp.asarray(B); act = jnp.asarray(active, float)

    def J(U):
        return float(J_state(U) + control_cost(U))

    def dJ(U):
        return grad_state(U) + dt * Bv[None, :] * U * act[None, :]
    return J, dJ, grad_state


def pmp_residual(U, grad_state_U, B, dt, active):
    """max |U - Proj_[0,1](-g/(dt B))| over active controls: zero iff the discrete
    Pontryagin condition holds."""
    act = np.asarray(active, bool)
    target = np.clip(-np.asarray(grad_state_U) / (dt * np.asarray(B)[None, :]), 0, 1)
    return float(np.max(np.abs(np.asarray(U)[:, act] - target[:, act])))


def lbfgsb(x0, p, W, B, T=730.0, dt=0.5, active=None, U0=None, maxiter=2000):
    """Independent solver: projected quasi-Newton (L-BFGS-B) on the same discrete problem."""
    from scipy.optimize import minimize
    nsteps = int(round(T / dt))
    active = np.ones(NCTRL, bool) if active is None else np.asarray(active, bool)
    J, dJ, gs = total_objective(x0, p, W, B, dt, nsteps, active)
    na = int(active.sum())
    def unpack(v):
        U = np.zeros((nsteps, NCTRL)); U[:, active] = v.reshape(nsteps, na); return jnp.asarray(U)
    def fun(v):
        U = unpack(v)
        return J(U), np.asarray(dJ(U))[:, active].reshape(-1)
    v0 = np.zeros(nsteps * na) if U0 is None else np.asarray(U0)[:, active].reshape(-1)
    sol = minimize(fun, v0, jac=True, method="L-BFGS-B", bounds=[(0, 1)] * (nsteps * na),
                   options={"maxiter": maxiter, "maxfun": maxiter * 2, "ftol": 1e-14, "gtol": 1e-10})
    U = unpack(sol.x)
    return U, sol, J(U)
