"""Mathematical verification suite (results/verify_math.json).

V1  Independent re-implementation of the model equations as printed in the paper
    (no code shared with model.py except the parameter dictionary) vs model.rhs.
V2  Conservation identity d/dt sum N = sum Lambda - sum mu N - deaths.
V3  Symbolic checks (sympy): closed forms for R_C and R_H (Corollary), the
    HIV-only endemic equilibrium (Proposition), and rank-one structure of the
    homogeneous COVID NGM.
V4  R0 = max(R_C, R_H) for the full 14-class NGM at the baseline and at random
    parameter sets (including R_H > R_C); block structure of F at the DFE.
V5  Type-reproduction number: rho((I - c*Pi)K) = 1 at c* = 1 - 1/T.
V6  Invasion numbers vs spectral abscissa of the full Jacobian at x^H, x^C.
V7  Global-stability theorem: conditions (theta<=1, iota condition), R_C^sharp,
    conservative lower bound N_low and resulting hat-R; numerical convergence to
    the DFE from random initial states when R_C = R_H = 0.9.
V8  Convergence to the coexistence equilibrium from random initial states.
"""
import json, time
import numpy as np
import jax, jax.numpy as jnp
import sympy as sp
from model import *
from repro import *
from common import P, load_primitive, equilibria

out = {}
p = P()
prim = load_primitive()
xH, xE, zH, zE = equilibria()

# ======================================================================= V1
def paper_rhs(x, u, p):
    """Equations (model) of the paper, coded directly from the LaTeX."""
    x = np.asarray(x, float); u = np.asarray(u, float)
    X = {n: x[IDX[n]].reshape(NA, NQ, NR) for n in NAMES[:NALIVE]}
    N = sum(X[n] for n in NAMES[:NALIVE])
    # --- contact operator M^C built from primitives
    Na = np.asarray(p["N0"]).reshape(NA, NQ, NR).sum(axis=(1, 2))
    c = np.asarray(p["c_raw"])
    csym = np.zeros((NA, NA))
    for i in range(NA):
        for j in range(NA):
            csym[i, j] = (c[i, j] * Na[i] + c[j, i] * Na[j]) / (2 * Na[i])
    pi = np.asarray(p["ses_share"]); sc = p["assort_C"]
    chi = 1 + p["g_crowd"] * (np.asarray(p["crowd_base"]) - 1)
    J = X["I"] + p["iota1"] * X["A"] + p["iotaC"] * (X["CL"] + X["CU"] + X["CT"])
    lamC = np.zeros((NA, NQ, NR))
    for i in range(NA):
        for n in range(NQ):
            tot = 0.0
            for j in range(NA):
                for k in range(NQ):
                    m = sc * (n == k) + (1 - sc) * pi[k]
                    tot += csym[i, j] * m * np.sqrt(chi[n] * chi[k]) * J[j, k].sum() / N[j, k].sum()
            lamC[i, n, :] = p["betaC"] * (1 - p["iso_eff"] * p["iso_max"] * u[6]) * tot
    # --- HIV force
    Y = (X["L"] + X["LR"] + p["kappaU"] * (X["U"] + X["UR"]) + p["epsT"] * (X["T"] + X["TR"] + X["CT"])
         + p["theta"] * (X["CL"] + p["kappaU"] * X["CU"]))
    Yf = Y.reshape(G); Nf = N.reshape(G)
    cg = np.asarray(p["c_sex"]); M = np.asarray(p["Msex"])
    lamH = ((1 - p["prev_max"] * u[5]) * p["betaH"] * cg * (M @ np.where(Nf > 0, Yf / np.where(Nf > 0, Nf, 1), 0))).reshape(NA, NQ, NR)
    # --- rates
    aV = (1 + p["g_vac"] * (np.asarray(p["vacacc_base"]) - 1))
    aT = (1 + p["g_art"] * (np.asarray(p["artacc_base"]) - 1))
    tgt = np.asarray(p["vac_w"]).reshape(NA, NQ, NR)
    nu = np.zeros((NA, NQ, NR)); tau = np.zeros_like(nu); tauU = np.zeros_like(nu)
    for n in range(NQ):
        nu[:, n, :] = (p["nu0"] * aV[n] + p["vmax"] * u[n]) * tgt[:, n, :]
        tau[:, n, :] = (p["tau"] * p["art_disrupt"] + p["tau_max"] * u[4]) * aT[n]
        tauU[:, n, :] = (p["tauU_mult"] * p["tau"] * p["art_disrupt"] + p["tau_max"] * u[4]) * aT[n]
    nuP = p["plhiv_vac_mult"] * nu
    xi = p["xi"] * p["xi_mult"]
    Psi = 1 - p["psi"] * u[7]
    mu = np.repeat(np.asarray(p["mu_age"]), NQ * NR).reshape(NA, NQ, NR)
    # --- severity, from the primitive definitions (eq. dC)
    hosp = np.clip(np.asarray(p["hosp_p"]) * p["hosp_mult"], 0, 0.5)
    fat = 1 + p["g_fatal"] * (np.asarray(p["fatal_base"]) - 1)
    fH = np.clip(np.asarray(p["fH"])[:, None] * p["fH_mult"] * fat[None, :], 0, 0.9)[:, :, None] * np.ones((1, 1, NR))
    dH = fH / p["LOS"]; gH = (1 - fH) / p["LOS"]
    delta = (p["gamma"] * hosp / (1 - hosp))[:, None, None] * np.ones((1, NQ, NR))
    IFR = (1 - p["rho"]) * hosp[:, None, None] * fH
    def dC(HR, gC):
        Pd = np.clip(HR * IFR, 0, 0.95); return gC * Pd / (1 - Pd)
    dCL, dCU, dCT = dC(p["HR_L"], p["gCL"]), dC(p["HR_U"], p["gCU"]), dC(p["HR_T"], p["gCT"])
    pa = p["rho"]; paV = 1 - (1 - pa) * (1 - p["epsSev"])
    eV, eP, zeta, vpi = p["epsV"], p["epsP"], p["eps"], p["epsPw"]
    sg, g, om, muT, muU = p["sigma"], p["gamma"], p["omega"], p["muT"], p["muU"]
    # --- demography operator A applied to a class (explicit loops)
    al = np.asarray(p["alpha_age"]); kout = p["kp_out"]
    sh = np.asarray(p["kp_age"])[:, None] * np.asarray(p["kp_ses"])[None, :]
    kin = np.zeros((NA, NQ)); kin[1:] = kout * sh[1:] / (1 - sh[1:])
    def Aop(Z):
        out_ = np.zeros_like(Z)
        for i in range(NA):
            for n in range(NQ):
                for r in range(NR):
                    out_[i, n, r] -= al[i] * Z[i, n, r]
                    if i == 1:
                        frac = sh[1, n] if r == 1 else 1 - sh[1, n]
                        out_[i, n, r] += al[0] * Z[0, n, :].sum() * frac
                    elif i >= 2:
                        out_[i, n, r] += al[i - 1] * Z[i - 1, n, r]
                    if i >= 1:
                        if r == 0:
                            out_[i, n, 0] += kout * Z[i, n, 1] - kin[i, n] * Z[i, n, 0]
                        else:
                            out_[i, n, 1] += kin[i, n] * Z[i, n, 0] - kout * Z[i, n, 1]
        return out_
    Lam = np.asarray(p["Lambda"]).reshape(NA, NQ, NR)
    S, V, E, EV, A, I, H, R = (X[k] for k in ["S", "V", "E", "EV", "A", "I", "H", "R"])
    L, T, U, LR, TR, UR, CL, CU, CT = (X[k] for k in ["L", "T", "U", "LR", "TR", "UR", "CL", "CU", "CT"])
    lC, lH = lamC, lamH
    d = {}
    d["S"] = Lam + p["eta"] * V + zeta * R - (lC + lH + nu + mu) * S + Aop(S)
    d["V"] = nu * S - ((1 - eV) * lC + lH + p["eta"] + mu) * V + Aop(V)
    d["E"] = lC * S - (sg + lH + mu) * E + Aop(E)
    d["EV"] = (1 - eV) * lC * V - (sg + lH + mu) * EV + Aop(EV)
    d["A"] = pa * sg * E + paV * sg * EV - (g + lH + mu) * A + Aop(A)
    d["I"] = (1 - pa) * sg * E + (1 - paV) * sg * EV - (g + delta + lH + mu) * I + Aop(I)
    d["H"] = delta * I - (gH + Psi * dH + mu) * H + Aop(H)
    d["R"] = g * (A + I) + gH * H - (zeta + lH + mu) * R + Aop(R)
    d["L"] = lH * S + xi * T + vpi * LR - (lC + tau + om + nuP + mu) * L + Aop(L)
    d["T"] = tau * L + tauU * U + vpi * TR - (lC + xi + nuP + mu + muT) * T + Aop(T)
    d["U"] = om * L + vpi * UR - (lC + tauU + nuP + mu + muU) * U + Aop(U)
    d["LR"] = lH * (V + R) + nuP * L + p["gCL"] * CL + xi * TR - ((1 - eP) * lC + tau + om + vpi + mu) * LR + Aop(LR)
    d["TR"] = nuP * T + p["gCT"] * CT + tau * LR + tauU * UR - ((1 - eP) * lC + xi + vpi + mu + muT) * TR + Aop(TR)
    d["UR"] = nuP * U + om * LR + p["gCU"] * CU - ((1 - eP) * lC + tauU + vpi + mu + muU) * UR + Aop(UR)
    d["CL"] = lC * (L + (1 - eP) * LR) + lH * (E + EV + A + I) + xi * CT - (p["gCL"] + tau + om + Psi * dCL + mu) * CL + Aop(CL)
    d["CU"] = lC * (U + (1 - eP) * UR) + om * CL - (p["gCU"] + tauU + Psi * dCU + mu + muU) * CU + Aop(CU)
    d["CT"] = lC * (T + (1 - eP) * TR) + tau * CL + tauU * CU - (p["gCT"] + xi + Psi * dCT + mu + muT) * CT + Aop(CT)
    d["Dcov"] = Psi * (dH * H + dCL * CL + dCU * CU + dCT * CT)
    d["Dhiv"] = muU * (U + UR + CU) + muT * (T + TR + CT)
    return np.stack([d[k].reshape(G) for k in NAMES[:NALIVE] + ["Dcov", "Dhiv"]])


rng = np.random.default_rng(7)
errs = []
for trial in range(6):
    q = dict(prim)
    if trial > 0:   # random parameter perturbation (also exercises gradients/knobs)
        for k in ["rho", "iota1", "iotaC", "epsV", "epsSev", "epsP", "HR_L", "HR_U", "theta", "kappaU", "epsT",
                  "g_crowd", "g_vac", "g_art", "g_fatal", "hosp_mult", "fH_mult", "assort_C", "xi", "omega"]:
            q[k] = q[k] * rng.uniform(0.6, 1.4)
        q["plhiv_vac_mult"] = rng.uniform(1, 5); q["art_disrupt"] = rng.uniform(0.5, 1); q["vac_w"] = rng.uniform(0.2, 2, G)
    qd = derive(q)
    x = jnp.asarray(rng.random((NX, G)) * rng.choice([1e-4, 1e-2, 1.0], size=(NX, G)))
    u = jnp.asarray(rng.random(NCTRL))
    a = np.asarray(rhs(x, u, qd))[list(range(NALIVE)) + [IDX["Dcov"], IDX["Dhiv"]]]
    b = paper_rhs(x, u, {**q, **{k: qd[k] for k in ["N0", "Lambda", "c_sex", "Msex"]}})
    rel = np.max(np.abs(a - b)) / np.max(np.abs(b))
    errs.append(float(rel))
out["V1_max_rel_diff_paper_vs_code"] = max(errs)
out["V1_trials"] = errs
print("V1 paper-vs-code max relative difference:", max(errs))

# ======================================================================= V2
cons = []
for trial in range(20):
    x = jnp.asarray(rng.random((NX, G)) * 1e-2); u = jnp.asarray(rng.random(NCTRL))
    dd = rhs(x, u, p)
    lhs = float(dd[:NALIVE].sum())
    rhs_ = float(p["Lambda"].sum() - (p["mu"] * x[:NALIVE].sum(0)).sum() - dd[IDX["Dcov"]].sum() - dd[IDX["Dhiv"]].sum())
    cons.append(abs(lhs - rhs_))
out["V2_conservation_max_abs"] = max(cons)
# balance of sexual partnerships and reciprocity of contacts
c = np.asarray(p["c_sex"]); N0 = np.asarray(p["N0"]); Ms = np.asarray(p["Msex"])
Z = (c * N0)[:, None] * Ms
out["V2_partnership_balance_max"] = float(np.abs(Z - Z.T).max() / Z.max())
Kc = np.asarray(p["K"]); Ncell = N0.reshape(NA * NQ, NR).sum(1)
W = Ncell[:, None] * Kc
out["V2_contact_reciprocity_max"] = float(np.abs(W - W.T).max() / W.max())
print("V2 conservation", out["V2_conservation_max_abs"], "balance", out["V2_partnership_balance_max"], "reciprocity", out["V2_contact_reciprocity_max"])

# ======================================================================= V3 (sympy)
b, cb, sg, mu, g, de, pa, paV, i1, S0, V0, N0s, eV = sp.symbols(
    "beta cbar sigma mu gamma delta p_a p_aV iota1 S0 V0 N0 epsV", positive=True)
# homogeneous COVID infected subsystem (E, EV, A, I, H)
F = sp.zeros(5, 5)
inf_row = sp.Matrix([[0, 0, i1, 1, 0]])
F[0, :] = b * cb * S0 / N0s * inf_row
F[1, :] = b * cb * (1 - eV) * V0 / N0s * inf_row
Vm = sp.Matrix([[sg + mu, 0, 0, 0, 0],
                [0, sg + mu, 0, 0, 0],
                [-pa * sg, -paV * sg, g + mu, 0, 0],
                [-(1 - pa) * sg, -(1 - paV) * sg, 0, g + de + mu, 0],
                [0, 0, 0, -de, 0]])
Vm[4, 4] = sp.Symbol("gH") + sp.Symbol("dH") + mu
K = F * Vm.inv()
rank = K.rank()
RC_ngm = sp.simplify(K.trace())
RC_paper = (b * cb * sg / (sg + mu)) * (S0 / N0s * (pa * i1 / (g + mu) + (1 - pa) / (g + de + mu))
                                        + (1 - eV) * V0 / N0s * (paV * i1 / (g + mu) + (1 - paV) / (g + de + mu)))
out["V3_RC_rank"] = int(rank)
out["V3_RC_closed_form_diff"] = str(sp.simplify(RC_ngm - RC_paper))
# HIV (L, T, U)
bH, c_, tau, om, xi_, tU, muT_, muU_, kU, kT = sp.symbols("beta_H c tau omega xi tau_U mu_T mu_U kappa_U kappa_T", positive=True)
VH = sp.Matrix([[tau + om + mu, -xi_, 0],
                [-tau, xi_ + mu + muT_, -tU],
                [-om, 0, tU + mu + muU_]])
FH = sp.zeros(3, 3); FH[0, :] = bH * c_ * sp.Matrix([[1, kT, kU]])
KH = FH * VH.inv()
RH_ngm = sp.simplify(KH[0, 0])
kL, kTT, kUU = tau + om + mu, xi_ + mu + muT_, tU + mu + muU_
r = tau + tU * om / kUU
RH_paper = bH * c_ * kTT / (kL * kTT - xi_ * r) * (1 + kT * r / kTT + kU * om / kUU)
out["V3_RH_closed_form_diff"] = str(sp.simplify(RH_ngm - RH_paper))
# Proposition: HIV-only equilibrium (mu_T = mu_U = 0)
lam, Lmb = sp.symbols("lambda Lambda", positive=True)
subs0 = {muT_: 0, muU_: 0}
t_vec = VH.subs(subs0).inv()[:, 0]
ell = sp.simplify(sum(t_vec))
RH0 = sp.simplify(RH_ngm.subs(subs0))
Sst = Lmb / (lam + mu)
Ivec = lam * Sst * t_vec
Yst = Ivec[0] + kT * Ivec[1] + kU * Ivec[2]
Nst = Sst + sum(Ivec)
fp = sp.simplify(bH * c_ * Yst / Nst - lam)
lam_star = sp.solve(sp.Eq(bH * c_ * Yst / Nst, lam), lam)
lam_claim = sp.simplify((RH0 - 1) / ell)
out["V3_prop_lambda_star_solutions"] = [str(sp.simplify(s - lam_claim)) for s in lam_star]
out["V3_prop_ell_equals_1_over_mu"] = str(sp.simplify(ell - 1 / mu))
prev = sp.simplify((sum(Ivec) / Nst).subs(lam, lam_claim))
out["V3_prop_prevalence_diff"] = str(sp.simplify(prev - (1 - 1 / RH0)))
print("V3", out["V3_RC_rank"], out["V3_RC_closed_form_diff"], out["V3_RH_closed_form_diff"],
      out["V3_prop_lambda_star_solutions"], out["V3_prop_ell_equals_1_over_mu"], out["V3_prop_prevalence_diff"])

# ======================================================================= V4
rows = []
x0 = dfe(p)
K, F, Vv = ngm(x0, p, ALL_INF, U0, "all")
co_rows = [ALL_INF.index(k) for k in ["CL", "CU", "CT"]]
co_idx = np.concatenate([np.arange(G) + G * r for r in co_rows])
out["V4_F_coinfection_rows_max"] = float(np.abs(F[co_idx]).max())
for trial in range(8):
    q = dict(prim)
    if trial > 0:
        q["betaC"] *= rng.uniform(0.2, 1.5); q["betaH"] *= rng.uniform(0.5, 4.0)
        q["xi"] *= rng.uniform(0.5, 2); q["rho"] *= rng.uniform(0.8, 1.2)
    qd = derive(q)
    rc, rh, r0 = R_C(qd)[0], R_H(qd)[0], R0_full(qd)
    rows.append([rc, rh, r0, abs(r0 - max(rc, rh)) / r0])
out["V4_R0_vs_max"] = rows
print("V4 R0 max rel err", max(r_[3] for r_ in rows), "cases with RH>RC:", sum(r_[1] > r_[0] for r_ in rows))

# ======================================================================= V5
rh, KH = R_H(p)
nH = len(HIV_DFE)
Pi = np.diag(np.tile(KPMASK, nH).astype(float)); Id = np.eye(KH.shape[0])
T_KP = spectral_radius(Pi @ KH @ np.linalg.inv(Id - (Id - Pi) @ KH))
cstar = 1 - 1 / T_KP
out["V5_T_KP"] = T_KP
out["V5_rho_rows_scaled_at_cstar"] = spectral_radius((Id - cstar * Pi) @ KH)
out["V5_rho_cols_scaled_at_cstar"] = spectral_radius(KH @ (Id - cstar * Pi))
out["V5_RH_lowrisk_only"] = spectral_radius((Id - Pi) @ KH @ (Id - Pi))
out["V5_RH_KP_only"] = spectral_radius(Pi @ KH @ Pi)
print("V5 T_KP", T_KP, "rho at c*", out["V5_rho_rows_scaled_at_cstar"], out["V5_rho_cols_scaled_at_cstar"])

# ======================================================================= V6
KCH, _, _ = ngm(xH, p, COVID_INF, U0, "covid")
RCH = spectral_radius(KCH)
xC, zC, resC, okC = foi_equilibrium(p, "covid")
KHC, _, _ = ngm(xC, p, HIV_INF, U0, "hiv")
RHC = spectral_radius(KHC)
eH_face = np.linalg.eigvals(jac_alive(xH, p, comps=HIV_ONLY_COMPS)).real.max()
eH_full = np.linalg.eigvals(jac_alive(xH, p)).real.max()
_, Fc, Vc = ngm(xH, p, COVID_INF, U0, "covid")
sFV = np.linalg.eigvals(Fc - Vc).real.max()
eC_face = np.linalg.eigvals(jac_alive(xC, p, comps=COVID_ONLY_COMPS)).real.max()
eC_full = np.linalg.eigvals(jac_alive(xC, p)).real.max()
_, Fh, Vh = ngm(xC, p, HIV_INF, U0, "hiv")
sFVh = np.linalg.eigvals(Fh - Vh).real.max()
ev_coex = np.linalg.eigvals(jac_alive(xE, p))
out["V6"] = {"RC_at_xH": RCH, "RH_at_xC": RHC,
             "xH_face_abscissa": float(eH_face), "xH_full_abscissa": float(eH_full), "s(F-V)_covid_at_xH": float(sFV),
             "xC_face_abscissa": float(eC_face), "xC_full_abscissa": float(eC_full), "s(F-V)_hiv_at_xC": float(sFVh),
             "coex_abscissa": float(ev_coex.real.max()), "coex_n_eigs": int(len(ev_coex)),
             "covid_eq_residual": resC}
print("V6", json.dumps(out["V6"], indent=0))

# ======================================================================= V7
# (a) theorem side conditions
delta_max = float(np.max(np.asarray(p["delta"])))
mu_max = float(np.max(np.asarray(p["mu"])))
out["V7_theta"] = float(p["theta"])
out["V7_iota_condition"] = {"iota1": float(p["iota1"]),
                            "bound_min_over_strata": float(np.min((p["gamma"] + np.asarray(p["mu"])) / (p["gamma"] + np.asarray(p["delta"]) + np.asarray(p["mu"]))))}
# (b) R_C^sharp: R_C at the DFE without vaccination (all susceptibles in S)
q0 = derive({**prim, "nu0": 0.0})
RCs = R_C(q0)[0]
out["V7_RC_sharp"] = RCs; out["V7_RC"] = R_C(p)[0]; out["V7_RC_sharp_ratio"] = RCs / out["V7_RC"]
# (c) conservative lower bound N_low using maximal per-capita disease mortality in each stratum
dCL, dCU, dCT = [np.asarray(v) for v in co_death_rates(p)]
dbar = np.max(np.stack([np.asarray(p["dH"]), dCL, dCU + float(p["muU"]), dCT + float(p["muT"]),
                        np.full(G, float(p["muU"])), np.full(G, float(p["muT"]))]), axis=0)
Pf, Qf = demography_operator(np.eye(G), {k: np.asarray(v) if isinstance(v, jnp.ndarray) else v for k, v in p.items()}, as_matrix=True)
Mlow = Pf - np.diag(Qf + np.asarray(p["mu"]) + dbar)
Nlow = -np.linalg.solve(Mlow, np.asarray(p["Lambda"]))
out["V7_Nlow_over_Nstar_min_adult"] = float(np.min((Nlow / np.maximum(np.asarray(p["N0"]), 1e-300))[np.asarray(p["N0"]) > 1e-12]))
# hat-R: replace the denominators N*_h of the source stratum (HIV) or source cell (COVID) by N_low
N0a = np.asarray(p["N0"])
sH = np.where(Nlow > 0, N0a / np.maximum(Nlow, 1e-300), 1.0)
Ncell_star = N0a.reshape(NA * NQ, NR).sum(1); Ncell_low = Nlow.reshape(NA * NQ, NR).sum(1)
sC = np.repeat(Ncell_star / Ncell_low, NR)
_, FHm, VHm = ngm(dfe(p), p, HIV_DFE, U0, "hiv")
_, FCm, VCm = ngm(dfe(q0), q0, COVID_INF, U0, "covid")
out["V7_hatR_H"] = spectral_radius(FHm @ np.diag(np.tile(sH, nH)) @ np.linalg.inv(VHm))
out["V7_hatR_C_sharp"] = spectral_radius(FCm @ np.diag(np.tile(sC, len(COVID_INF))) @ np.linalg.inv(VCm))
print("V7", out["V7_iota_condition"], "RCsharp ratio", out["V7_RC_sharp_ratio"], "Nlow/N* min", out["V7_Nlow_over_Nstar_min_adult"],
      "hatRH", out["V7_hatR_H"], "hatRC#", out["V7_hatR_C_sharp"])
# (d) numerical: R_C = R_H = 0.9 -> convergence to the DFE from random initial states
q9 = dict(prim); q9["betaC"] *= 0.9 / R_C(p)[0]; q9["betaH"] *= 0.9 / R_H(p)[0]
p9 = derive(q9)
x09 = dfe(p9)
finals = []
t0 = time.time()
for trial in range(12):
    w = rng.dirichlet(np.ones(NALIVE), size=G).T                   # random split of each stratum
    x = jnp.zeros((NX, G)).at[:NALIVE].set(jnp.asarray(w) * p9["N0"][None, :] * rng.uniform(0.5, 1.0))
    xs = run_jit(x, p9, 3000 * 365.0, 10.0, U0, "nsfd")
    xf = xs[-1]
    inf_ = float(sum(xf[IDX[k]] for k in ALL_INF).sum())
    dist = float(jnp.abs(xf[:NALIVE] - x09[:NALIVE]).max())
    finals.append([inf_, dist])
out["V7_random_ic_R09_final_infected_and_dist"] = finals
print("V7 R=0.9 random ICs: max infected", max(f[0] for f in finals), "max dist", max(f[1] for f in finals), time.time() - t0)

# ======================================================================= V8
fin = []
for trial in range(12):
    w = rng.dirichlet(np.ones(NALIVE), size=G).T
    x = jnp.zeros((NX, G)).at[:NALIVE].set(jnp.asarray(w) * p["N0"][None, :] * rng.uniform(0.5, 1.0))
    xs = run_jit(x, p, 3000 * 365.0, 10.0, U0, "nsfd")
    xf = xs[-1]
    rel = float(jnp.max(jnp.abs(xf[:NALIVE] - xE[:NALIVE]) / (jnp.abs(xE[:NALIVE]) + 1e-12)))
    fin.append([rel, adult_prev(xf), float(sum(xf[IDX[k]] for k in COVID_INF).sum())])
out["V8_random_ic_to_coex"] = fin
out["V8_coex_adult_prev"] = adult_prev(xE)
print("V8 max rel dist to coexistence eq after 3000 y:", max(f[0] for f in fin))
json.dump(out, open("results/verify_math.json", "w"), indent=1, default=float)
print("done")
