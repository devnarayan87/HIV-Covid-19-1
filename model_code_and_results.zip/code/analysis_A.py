"""Threshold quantities and equilibrium properties at the calibrated baseline
(results/A_thresholds.json)."""
import json
import numpy as np
import jax.numpy as jnp
from common import *

p = P(); prim = load_primitive()
xH, xE, zH, zE = equilibria()
out = {}
rc, KC = R_C(p); rh, KH = R_H(p)
out["R_C"], out["R_H"], out["R0_full"] = rc, rh, R0_full(p)
xC, zC, resC, okC = foi_equilibrium(p, "covid")
out["R_C_at_HIV_eq"] = spectral_radius(ngm(xH, p, COVID_INF, U0, "covid")[0])
out["R_H_at_COVID_eq"] = spectral_radius(ngm(xC, p, HIV_INF, U0, "hiv")[0])
# secondary SARS-CoV-2 infections per index case entering each class, at x^H (NGM column sums)
K_xH = ngm(xH, p, COVID_INF, U0, "covid")[0]
cs = K_xH.sum(axis=0).reshape(len(COVID_INF), G)
adults = np.zeros((NA, NQ, NR)); adults[1:] = 1; adults = adults.reshape(G)
def wmean(v, w): return float((v * w).sum() / w.sum())
for k, src in [("E", "S"), ("CL", "L"), ("CU", "U"), ("CT", "T")]:
    out[f"index_{k}_mean"] = wmean(cs[COVID_INF.index(k)], np.asarray(xH[IDX[src]]) * adults)
# stratum reproduction numbers of SARS-CoV-2 (index case entering E in stratum g, DFE)
csd = KC.sum(axis=0).reshape(len(COVID_INF), G)[0]
N0 = np.asarray(p["N0"])
out["RC_strata"] = ((csd * N0).reshape(NA, NQ, NR).sum(2) / N0.reshape(NA, NQ, NR).sum(2)).tolist()
# type-reproduction number and restricted numbers for key populations
nH = len(HIV_DFE)
Pi = np.diag(np.tile(KPMASK, nH).astype(float)); Id = np.eye(KH.shape[0])
out["T_KP"] = spectral_radius(Pi @ KH @ np.linalg.inv(Id - (Id - Pi) @ KH))
out["R_H_lowrisk_only"] = spectral_radius((Id - Pi) @ KH @ (Id - Pi))
out["R_H_KP_only"] = spectral_radius(Pi @ KH @ Pi)
# epidemiology at the coexistence equilibrium (per 100 000 per year)
lamC, lamH, N = forces(xE, U0, p)
neg = sum(xE[IDX[k]] for k in ["S", "V", "R", "E", "EV", "A", "I"])
dd = rhs(xE, U0, p)
out["hiv_incidence_per_100k_yr"] = float((lamH * neg).sum() * 365 * 1e5)
out["aids_deaths_per_100k_yr"] = float(dd[IDX["Dhiv"]].sum() * 365 * 1e5)
out["covid_deaths_per_100k_yr"] = float(dd[IDX["Dcov"]].sum() * 365 * 1e5)
out["covid_infected_frac"] = float(sum(xE[IDX[k]] for k in COVID_INF).sum())
out["prev_adult_HIVonly"], out["prev_adult_coex"] = adult_prev(xH), adult_prev(xE)
out["prev_KP_HIVonly"], out["prev_KP_coex"] = kp_prev(xH), kp_prev(xE)
out["art_coex"] = art_cov(xE)
out["plhiv_frac"] = float(plhiv(xE).sum())
# KP shares by age at the DFE (stationary demography)
Nd = N0.reshape(NA, NQ, NR)
out["kp_share_by_age"] = (Nd[..., 1].sum(1) / Nd.sum((1, 2))).tolist()
out["age_share"] = np.asarray(p["age_share"]).tolist()
# spectra
ev = np.linalg.eigvals(jac_alive(xE, p)); out["coex_max_re_eig"] = float(ev.real.max())
ev = np.linalg.eigvals(jac_alive(xH, p, comps=HIV_ONLY_COMPS)); out["hivonly_max_re_eig_face"] = float(ev.real.max())
ev = np.linalg.eigvals(jac_alive(xH, p)); out["hivonly_max_re_eig_full"] = float(ev.real.max())
ev = np.linalg.eigvals(jac_alive(xC, p)); out["covidonly_max_re_eig_full"] = float(ev.real.max())
ev = np.linalg.eigvals(jac_alive(dfe(p), p)); out["dfe_max_re_eig"] = float(ev.real.max())
out["relaxation_years_hiv"] = 1 / abs(out["hivonly_max_re_eig_face"]) / 365
out["eq_residuals"] = {"xH": float(jnp.abs(rhs(xH, U0, p)[:NALIVE]).max()),
                       "xE": float(jnp.abs(rhs(xE, U0, p)[:NALIVE]).max()), "xC": resC}
json.dump(out, open("results/A_thresholds.json", "w"), indent=1)
print(json.dumps({k: v for k, v in out.items() if k != "RC_strata"}, indent=1))
