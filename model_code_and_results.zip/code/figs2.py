"""Manuscript figures (BMB: sans-serif lettering, vector PDF + EPS, 174 mm width).
Reads results/*.json; writes manuscript/Fig*.pdf and .eps."""
import json, os, glob
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm

OUT = "manuscript"
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
SEQ = LinearSegmentedColormap.from_list("blue", ["#eef4fc", "#9cc3ef", "#2a78d6", "#123e73"])
DIV = LinearSegmentedColormap.from_list("div", ["#2a78d6", "#f2f1ee", "#eb6834"])
MM = 1 / 25.4
W2 = 174 * MM
plt.rcParams.update({"font.family": "Liberation Sans", "font.size": 8, "axes.edgecolor": INK2,
                     "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
                     "lines.linewidth": 1.6, "legend.frameon": False, "savefig.dpi": 600,
                     "axes.titlesize": 8.5, "axes.titleweight": "bold", "axes.titlelocation": "left",
                     "pdf.fonttype": 42, "ps.fonttype": 42})
R = lambda f: json.load(open(os.path.join("results", f)))
A = R("A_thresholds.json"); B = R("B_thresholds.json"); CS = R("C_scenarios.json")
D = R("D_nsfd.json"); F = R("F_control.json")
E = R("E_uncertainty.json") if os.path.exists("results/E_uncertainty.json") else None
Gr = R("G_robustness.json") if os.path.exists("results/G_robustness.json") else None
AGES = ["0–14", "15–29", "30–44", "45–59", "60+"]


def _nice():
    import ast
    src = open("make_numbers2.py").read()
    i = src.index("nice = {"); j = src.index("}", i)
    while True:
        try: return ast.literal_eval(src[i + 7:j + 1])
        except Exception: j = src.index("}", j + 1)

def panel(ax, s, x=-0.14):
    ax.text(x, 1.06, s, transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom")


def save(fig, name):
    fig.savefig(f"{OUT}/{name}.pdf"); fig.savefig(f"{OUT}/{name}.eps"); plt.close(fig)


# ---------------------------------------------------------------- Fig 2
fig, axs = plt.subplots(1, 2, figsize=(W2, 62 * MM), gridspec_kw={"width_ratios": [1.15, 1]})
Rm = np.array(A["RC_strata"]); ax = axs[0]; ax.grid(False)
im = ax.imshow(Rm, cmap=SEQ, vmin=Rm.min() * 0.95, vmax=Rm.max())
for i in range(Rm.shape[0]):
    for j in range(Rm.shape[1]):
        ax.text(j, i, f"{Rm[i, j]:.2f}", ha="center", va="center", fontsize=7,
                color="white" if Rm[i, j] > Rm.min() + 0.6 * (Rm.max() - Rm.min()) else INK)
ax.set_xticks(range(4), ["Q1", "Q2", "Q3", "Q4"]); ax.set_yticks(range(5), AGES)
ax.set_xlabel("Deprivation quartile (Q1 most deprived)"); ax.set_ylabel("Age group (years)")
ax.set_title("Stratum reproduction number, SARS-CoV-2")
cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03); cb.outline.set_visible(False); panel(ax, "a")
ax = axs[1]
labs = ["HIV-negative", "Co-infected,\nsuppressed", "Co-infected,\nunsuppressed", "Co-infected,\nadvanced HIV"]
vals = [A["index_E_mean"], A["index_CT_mean"], A["index_CL_mean"], A["index_CU_mean"]]
ax.barh(range(4), vals, color=[C[0], C[2], C[3], C[1]], height=0.55)
for k, v in enumerate(vals):
    ax.text(v + 0.08, k, f"{v:.2f}", va="center", fontsize=7.5, color=INK)
ax.set_yticks(range(4), labs); ax.invert_yaxis(); ax.grid(axis="y", visible=False)
ax.set_xlabel("Secondary SARS-CoV-2 infections per index case")
ax.set_title("Index case, HIV-endemic setting"); ax.set_xlim(0, max(vals) * 1.22); panel(ax, "b")
fig.tight_layout(); save(fig, "Fig2")

# ---------------------------------------------------------------- Fig 3
fig, axs = plt.subplots(1, 2, figsize=(W2, 62 * MM))
g = B["RH_grid"]; X, Y = np.meshgrid(g["art_mult"], np.array(g["prev"]) * 100); Z = np.array(g["R"])
ax = axs[0]; ax.grid(False)
cs = ax.contourf(X, Y, Z, levels=14, cmap=DIV, norm=TwoSlopeNorm(1.0, Z.min(), max(Z.max(), 1.01)))
ax.contour(X, Y, Z, levels=[1.0], colors=INK, linewidths=1.5)
ax.plot(1, 0, "o", color=INK, ms=4, clip_on=False); ax.annotate("baseline", (1, 0), (1.15, 1.2), fontsize=7)
ax.set_xlabel("ART initiation rate (× baseline)"); ax.set_ylabel("Reduction in HIV transmission (%)")
ax.set_title(r"$\mathcal{R}_H$ (black: $\mathcal{R}_H=1$)")
cb = fig.colorbar(cs, ax=ax, fraction=0.046, pad=0.03); cb.outline.set_visible(False); panel(ax, "a")
g = B["RC_grid"]; X, Y = np.meshgrid(g["vac"], g["iso"]); Z = np.array(g["R"])
ax = axs[1]; ax.grid(False)
cs = ax.contourf(X, Y, Z, levels=14, cmap=SEQ)
cl = ax.contour(X, Y, Z, levels=[1.5, 2.0, 2.5], colors="white", linewidths=0.8); ax.clabel(cl, fmt="%.1f", fontsize=6.5)
ax.set_xlabel("Sustained vaccination effort $u_1$"); ax.set_ylabel("Test-and-isolate effort $u_4$")
ax.set_title(r"$\mathcal{R}_C$ under sustained controls")
cb = fig.colorbar(cs, ax=ax, fraction=0.046, pad=0.03); cb.outline.set_visible(False); panel(ax, "b")
fig.tight_layout(); save(fig, "Fig3")

# ---------------------------------------------------------------- Fig 4
fig, axs = plt.subplots(1, 2, figsize=(W2, 55 * MM))
for ax, key, lab, title, ylab in [(axs[0], "bif_covid", r"$\mathcal{R}_C$", "SARS-CoV-2 (HIV absent)", "Infected (% of population)"),
                                  (axs[1], "bif_hiv", r"$\mathcal{R}_H$", "HIV (SARS-CoV-2 absent)", "Adult HIV prevalence (%)")]:
    b = np.array(B[key]); b = b[np.argsort(b[:, 0])]
    r, prev = b[:, 0], b[:, 1] * 100; end = prev > 0
    ax.plot(r[end], prev[end], color=C[1], label="endemic equilibrium (stable)")
    rr = np.linspace(r.min(), 1, 10); ax.plot(rr, 0 * rr, color=C[0], label="DFE (stable)")
    rr = np.linspace(1, r.max(), 10); ax.plot(rr, 0 * rr, color=C[0], ls="--", label="DFE (unstable)")
    ax.axvline(1, color=INK2, lw=0.7, ls=":"); ax.set_xlabel(lab); ax.set_title(title); ax.set_ylabel(ylab)
axs[0].legend(fontsize=6.8, loc="upper left"); panel(axs[0], "a"); panel(axs[1], "b")
fig.tight_layout(); save(fig, "Fig4")

# ---------------------------------------------------------------- Fig 5
sc = CS["scenarios"]; S0 = sc["S0"]; tr = CS["traj"]
fig, axs = plt.subplots(1, 3, figsize=(W2, 55 * MM))
ax = axs[0]; t = np.array(tr["t"])
ax.plot(t, tr["I"], color=C[0], label="SARS-CoV-2 infected, HIV-negative")
ax.plot(t, np.array(tr["H"]) * 100, color=C[1], label="Hospital occupancy (×100)")
ax.set_ylabel("Per 100 000"); ax.set_xlabel("Days after immune escape"); ax.set_title("Wave dynamics")
ax.legend(fontsize=6.3, loc="upper right"); ax.set_ylim(0, max(max(tr["I"]), 100 * max(tr["H"])) * 1.35); panel(ax, "a")
ax = axs[1]
ax.bar(range(5), S0["mort_by_age_per100k"], color=C[0], width=0.6)
ax.set_xticks(range(5), AGES, fontsize=7); ax.set_xlabel("Age group (years)"); ax.set_ylabel("COVID-19 deaths per 100 000")
ax.set_title("Mortality by age"); ax.grid(axis="x", visible=False); panel(ax, "b")
ax = axs[2]
ax.bar(range(4), S0["mort_by_quartile_agestd_per100k"], color=C[1], width=0.6)
ax.set_xticks(range(4), ["Q1", "Q2", "Q3", "Q4"]); ax.set_xlabel("Deprivation quartile")
ax.set_ylabel("Age-standardised deaths per 100 000"); ax.set_title("Mortality by deprivation")
ax.grid(axis="x", visible=False); panel(ax, "c")
fig.tight_layout(); save(fig, "Fig5")

# ---------------------------------------------------------------- ensemble helpers
ens = []
for f in sorted(glob.glob("results/ensemble/sample_*.json")):
    r = json.load(open(f))
    if r.get("ok"):
        ens.append(r)
def ens_q(fun):
    if not ens: return None
    v = np.array([fun(r) for r in ens]); return np.quantile(v, [0.025, 0.5, 0.975])

# ---------------------------------------------------------------- Fig 6
names = CS["names"]; keys = [k for k in sc if k != "S0"]
short = {"S1": "HIV-service disruption", "S2": "Rapid ART", "S3": "Vacc.: uniform", "S4": "Vacc.: age 60+ first",
         "S5": "Vacc.: PLHIV prioritised", "S6": "Vacc.: deprivation-weighted", "S7": "Vacc.: prop. universalism",
         "S8": "Vacc.: prop. univ. + PLHIV", "S9": "Test-and-isolate", "S10": "Enhanced clinical care",
         "S11": "Integrated package"}
fig, axs = plt.subplots(1, 3, figsize=(W2, 78 * MM), sharey=True)
y = np.arange(len(keys))
metrics = [("covid_deaths_averted_per100k", C[0], "COVID-19 deaths averted", "per 100 000 population", lambda r, k: r["scenarios"][k]["covid_deaths_averted_per100k"]),
           ("plhiv_deaths_averted_per100k_PLHIV", C[6], "COVID-19 deaths averted, PLHIV", "per 100 000 PLHIV", lambda r, k: r["scenarios"][k]["plhiv_deaths_averted_per100k_PLHIV"]),
           ("dhiv", C[1], "Change in new HIV infections", "per 100 000 population", lambda r, k: r["scenarios"][k]["new_hiv_per100k"] - r["scenarios"]["S0"]["new_hiv_per100k"])]
for ax, (m, col, ttl, xl, ef) in zip(axs, metrics):
    if m == "dhiv":
        v = [sc[k]["new_hiv_per100k"] - S0["new_hiv_per100k"] for k in keys]
    else:
        v = [sc[k][m] for k in keys]
    ax.barh(y, v, color=col, height=0.6)
    if ens:
        qs = np.array([ens_q(lambda r, k=k: ef(r, k)) for k in keys])
        ax.errorbar(qs[:, 1], y, xerr=[qs[:, 1] - qs[:, 0], qs[:, 2] - qs[:, 1]], fmt="o", ms=2.5, color=INK, elinewidth=0.8, capsize=1.5)
    ax.axvline(0, color=INK2, lw=0.7); ax.set_title(ttl); ax.set_xlabel(xl); ax.grid(axis="y", visible=False)
axs[0].set_yticks(y, [short[k] for k in keys], fontsize=7); axs[0].invert_yaxis()
for ax, s in zip(axs, "abc"): panel(ax, s)
fig.tight_layout(); save(fig, "Fig6")

# ---------------------------------------------------------------- Fig 7 (efficiency-equity plane)
vk = ["S0", "S3", "S4", "S5", "S6", "S7", "S8"]
lab7 = {"S0": "No campaign", "S3": "Uniform", "S4": "Age 60+ first", "S5": "PLHIV prioritised",
        "S6": "Deprivation-weighted", "S7": "Prop. universalism", "S8": "Prop. univ. + PLHIV"}
fig, ax = plt.subplots(figsize=(110 * MM, 75 * MM))
for k_, k in enumerate(vk):
    xv, yv = sc[k]["covid_deaths_averted_per100k"], sc[k]["RR_Q1_Q4"]
    if ens and k != "S0":
        xs = np.array([r["scenarios"][k]["covid_deaths_averted_per100k"] for r in ens])
        ys = np.array([r["scenarios"][k]["RR_Q1_Q4"] / r["scenarios"]["S0"]["RR_Q1_Q4"] * S0["RR_Q1_Q4"] for r in ens])
        ax.plot([np.quantile(xs, .25), np.quantile(xs, .75)], [yv, yv], color=C[k_ % 8], lw=0.9, alpha=0.7)
    ax.plot(xv, yv, "o", color=C[k_ % 8], ms=6, mec="white", mew=1.0, label=lab7[k])
ax.set_xlabel("COVID-19 deaths averted per 100 000 (equal doses)"); ax.set_ylabel("Mortality rate ratio Q1/Q4")
ax.set_title("Efficiency and equity of vaccine allocation"); ax.legend(fontsize=6.5, loc="best")
fig.tight_layout(); save(fig, "Fig7")

# ---------------------------------------------------------------- Fig 8 (optimal control)
Fc = np.load("results/F_controls.npz"); tc = Fc["t"]
fig, axs = plt.subplots(2, 2, figsize=(W2, 110 * MM))
U = Fc["Integrated_syndemic_package"]; Ue = Fc["Integrated_equity-weighted"]
ax = axs[0, 0]
for j, lab in enumerate(["Q1", "Q2", "Q3", "Q4"]):
    ax.plot(tc, U[:, j], color=C[j], label=lab); ax.plot(tc, Ue[:, j], color=C[j], ls="--", lw=1.1)
ax.set_title("Vaccination by quartile (dashed: equity-weighted)"); ax.set_ylabel("Control intensity"); ax.set_xlabel("Day")
ax.legend(fontsize=6.5, ncol=4, loc="upper right"); panel(ax, "a")
ax = axs[0, 1]
for j, lab, col in [(4, "ART acceleration $u_2$", C[5]), (5, "HIV prevention $u_3$", C[6]),
                    (6, "Test-and-isolate $u_4$", C[4]), (7, "Enhanced care $u_5$", C[7])]:
    ax.plot(tc, U[:, j], color=col, label=lab)
ax.set_ylabel("Control intensity"); ax.set_xlabel("Day"); ax.legend(fontsize=6.5); ax.set_title("Other controls (integrated)"); panel(ax, "b")
T = F["traj"]; t = np.array(T["t"])
ax = axs[1, 0]
ax.plot(t, T["unc_H"], color=C[1], label="hospital occupancy, no control")
ax.plot(t, T["opt_H"], color=C[1], ls="--", label="hospital occupancy, optimal")
ax.plot(t, T["unc_C"], color=C[6], label="co-infected, no control")
ax.plot(t, T["opt_C"], color=C[6], ls="--", label="co-infected, optimal")
ax.set_ylabel("Per 100 000"); ax.set_xlabel("Day"); ax.legend(fontsize=6.5); ax.set_title("Burden"); panel(ax, "c")
ax = axs[1, 1]
runs = F["runs"]; rn = ["No control", "COVID-only package", "HIV-only package", "Integrated syndemic package", "Integrated, equity-weighted"]
cd = [runs[k]["metrics"]["covid_deaths"] for k in rn]; nh = [runs[k]["metrics"]["new_hiv"] for k in rn]
x = np.arange(len(rn)); w = 0.38
ax.bar(x - w / 2, cd, w, color=C[0], label="COVID-19 deaths"); ax.bar(x + w / 2, nh, w, color=C[1], label="New HIV infections")
ax.set_xticks(x, ["None", "COVID\nonly", "HIV\nonly", "Integrated", "Integrated\n+ equity"], fontsize=6.8)
ax.set_ylabel("Per 100 000 over 2 years"); ax.legend(fontsize=6.5); ax.grid(axis="x", visible=False)
ax.set_title("Outcomes by package"); panel(ax, "d")
fig.tight_layout(); save(fig, "Fig8")

# ---------------------------------------------------------------- Fig 9 (robustness)
if E is not None and Gr is not None:
    fig = plt.figure(figsize=(W2, 120 * MM))
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.05])
    ax = fig.add_subplot(gs[0, 0])
    pr = E["ranking_probabilities"]
    items = [("S1_more_hiv_than_S0", "Disruption raises HIV incidence"),
             ("S4_more_than_S3", "Age 60+ first beats uniform"),
             ("S7_vs_S4_deaths_within_5pct", "Prop. univ. within 5% of age 60+"),
             ("S7_RR_lower_than_S4", "Prop. univ. narrows gap vs age 60+"),
             ("S4_RR_higher_than_S0", "Age 60+ first widens Q1/Q4 ratio"),
             ("S8_PLHIV_lower_than_S7", "PLHIV priority lowers PLHIV deaths"),
             ("S8_deaths_within_1pct_of_S7", "PLHIV priority costs <1% of deaths averted"),
             ("S10_more_than_S9", "Care averts more deaths than isolation"),
             ("S11_best_deaths", "Integrated package averts most deaths")]
    yy = np.arange(len(items))
    ax.barh(yy, [100 * pr[k] for k, _ in items], color=C[2], height=0.6)
    ax.set_yticks(yy, [l for _, l in items], fontsize=6.5); ax.invert_yaxis(); ax.set_xlim(0, 100)
    ax.set_xlabel("Ensemble samples where statement holds (%)"); ax.set_title("Robustness of conclusions"); ax.grid(axis="y", visible=False)
    panel(ax, "a", -0.62)
    ax = fig.add_subplot(gs[0, 1])
    vn = list(Gr.keys())
    rr0 = [Gr[k]["scenarios"]["S0"]["RR_Q1_Q4"] for k in vn]
    rr4 = [Gr[k]["scenarios"]["S4"]["RR_Q1_Q4"] for k in vn]
    rr7 = [Gr[k]["scenarios"]["S7"]["RR_Q1_Q4"] for k in vn]
    yv = np.arange(len(vn))
    ax.plot(rr0, yv, "o", color=INK2, ms=3.5, label="no campaign")
    ax.plot(rr4, yv, "s", color=C[1], ms=3.5, label="age 60+ first")
    ax.plot(rr7, yv, "D", color=C[0], ms=3.5, label="prop. universalism")
    ax.set_yticks(yv, [v.replace("R_C", r"$\mathcal{R}_C$") for v in vn], fontsize=6); ax.invert_yaxis(); ax.axvline(1, color=INK2, lw=0.6, ls=":")
    ax.set_xlabel("Mortality rate ratio Q1/Q4"); ax.set_title("Structural variants"); ax.legend(fontsize=6, loc="upper center", bbox_to_anchor=(0.5, -0.30), ncol=3, handletextpad=0.2, columnspacing=0.8)
    panel(ax, "b", -0.75)
    ax = fig.add_subplot(gs[1, :]); ax.grid(False)
    pc = E["prcc"]; params = pc["params"]
    outs = ["R_H", "T_KP", "deaths_S0", "plhiv_deaths_S0", "RR_S0", "disrupt_extra_hiv_pct", "S7_minus_S4_RR"]
    olab = [r"$\mathcal{R}_H$", r"$\mathcal{T}_{KP}$", "Deaths", "Deaths, PLHIV", "RR Q1/Q4", "Disruption ΔHIV", "RR(S7)−RR(S4)"]
    Mx = np.array([pc["values"][o] for o in outs])
    keep = np.where(np.max(np.abs(Mx), axis=0) >= 0.3)[0]
    im = ax.imshow(Mx[:, keep], cmap=DIV, vmin=-1, vmax=1, aspect="auto")
    ax.set_yticks(range(len(outs)), olab, fontsize=6.8); ax.set_xticks(range(len(keep)), [_nice().get(params[i], params[i]) for i in keep], rotation=60, ha="right", fontsize=6.3)
    for i in range(len(outs)):
        for j, jj in enumerate(keep):
            v = Mx[i, jj]
            if abs(v) >= 0.3: ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=5.2, color="white" if abs(v) > 0.7 else INK)
    ax.set_title("Partial rank correlation coefficients (inputs with |PRCC| ≥ 0.3 for some output)")
    cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.01); cb.outline.set_visible(False); panel(ax, "c", -0.07)
    fig.tight_layout(); save(fig, "Fig9")

# ---------------------------------------------------------------- Fig 10 (NSFD convergence)
cv = D["convergence"]; h = np.array([r["h"] for r in cv])
fig, ax = plt.subplots(figsize=(84 * MM, 62 * MM))
for sch, col, lab in [("nsfd", C[0], "NSFD"), ("euler", C[1], "explicit Euler"), ("rk4", C[2], "RK4")]:
    e = np.array([r[sch + "_err_inf"] for r in cv], float); ok = np.isfinite(e) & (e > 0)
    ax.loglog(h[ok], e[ok], "o-", color=col, label=lab, ms=3.5)
e1 = np.array([r["nsfd_err_inf"] for r in cv]); ax.loglog(h, e1[-1] * h / h[-1], ":", color=INK2, lw=0.9, label="slope 1")
ax.set_xlabel("Step size $h$ (days)"); ax.set_ylabel("Max. relative error (infected)"); ax.set_title("Convergence"); ax.legend(fontsize=6.5)
fig.tight_layout(); save(fig, "Fig10")
print("figures written; ensemble samples used:", len(ens))
