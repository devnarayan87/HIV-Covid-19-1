"""Next-generation matrices, reproduction numbers and exact equilibria."""
import numpy as np
import jax
import jax.numpy as jnp
from scipy.optimize import root as _root
from model import *

U0 = jnp.zeros(NCTRL)

COVID_INF = ["E", "EV", "A", "I", "H", "CL", "CU", "CT"]       # SARS-CoV-2-infected classes
HIV_INF = ["L", "T", "U", "LR", "TR", "UR", "CL", "CU", "CT"]   # HIV-infected classes
HIV_DFE = ["L", "T", "U", "LR", "TR", "UR"]                     # HIV-infected, COVID-free
ALL_INF = ["E", "EV", "A", "I", "H", "L", "T", "U", "LR", "TR", "UR", "CL", "CU", "CT"]
HIV_ONLY_COMPS = ["S", "V", "R", "L", "T", "U", "LR", "TR", "UR"]
COVID_ONLY_COMPS = ["S", "V", "E", "EV", "A", "I", "H", "R"]
ALIVE_COMPS = NAMES[:NALIVE]
KPMASK = np.zeros((NA, NQ, NR), bool); KPMASK[1:, :, 1] = True; KPMASK = KPMASK.reshape(G)


def _pc(p):
    """Parameter pytree with only numeric leaves (for jit)."""
    return {k: (jnp.asarray(v) if isinstance(v, (np.ndarray, jnp.ndarray)) else jnp.asarray(float(v)))
            for k, v in p.items() if isinstance(v, (float, int, np.ndarray, jnp.ndarray)) and not isinstance(v, bool)}


# ------------------------------------------------------------------ new-infection maps (the F part)
def new_infections(x, u, p, which="all"):
    """Appearance of new infections in each compartment (Fcal in the paper)."""
    S, V, E, EV, A, I, H, R, L, T, U, LR, TR, UR, CL, CU, CT = [x[k] for k in range(NALIVE)]
    lamC, lamH, N = forces(x, u, p)
    eV, eP = p["epsV"], p["epsP"]
    out = jnp.zeros((NX, G))
    if which in ("all", "covid"):
        out = out.at[IDX["E"]].add(lamC * S)
        out = out.at[IDX["EV"]].add(lamC * (1 - eV) * V)
        out = out.at[IDX["CL"]].add(lamC * (L + (1 - eP) * LR))
        out = out.at[IDX["CU"]].add(lamC * (U + (1 - eP) * UR))
        out = out.at[IDX["CT"]].add(lamC * (T + (1 - eP) * TR))
    if which in ("all", "hiv"):
        out = out.at[IDX["L"]].add(lamH * S)
        out = out.at[IDX["LR"]].add(lamH * (V + R))
        out = out.at[IDX["CL"]].add(lamH * (E + EV + A + I))
    return out


def _ngm_core(xeq, p, idx, u, which):
    n = len(idx)
    def sub(y):
        return xeq.at[idx].set(y.reshape(n, G))
    y0 = xeq[idx].reshape(-1)
    F = jax.jacfwd(lambda y: new_infections(sub(y), u, p, which)[idx].reshape(-1))(y0)
    J = jax.jacfwd(lambda y: rhs(sub(y), u, p)[idx].reshape(-1))(y0)
    V = F - J
    return F, V


_ngm_jit = {}


def ngm(xeq, p, infected, u=U0, which="all"):
    """Returns K = F V^{-1}, F, V (numpy) for the listed infected compartments at xeq."""
    key = (tuple(infected), which)
    if key not in _ngm_jit:
        idx = jnp.array([IDX[k] for k in infected])
        _ngm_jit[key] = jax.jit(lambda x, pp, uu: _ngm_core(x, pp, idx, uu, which))
    F, V = _ngm_jit[key](jnp.asarray(xeq), _pc(p), jnp.asarray(u))
    F = np.asarray(F); V = np.asarray(V)
    K = F @ np.linalg.inv(V)
    return K, F, V


def spectral_radius(K):
    return float(np.max(np.abs(np.linalg.eigvals(K))))


# ------------------------------------------------------------------ linear solves / DFE
def _linear_eq(lamC, lamH, p, comps, u=U0):
    """State that balances all flows when the forces of infection are held fixed."""
    idx = jnp.array([IDX[k] for k in comps])
    z = jnp.zeros((NX, G))
    def f(y):
        xx = z.at[idx].set(y.reshape(len(comps), G))
        P, Q = PQ(xx, u, p, lam=(lamC, lamH))
        return (P - Q * xx)[idx].reshape(-1)
    y0 = jnp.zeros(len(comps) * G)
    c = f(y0)
    J = jax.jacfwd(f)(y0)
    y = jnp.linalg.solve(J, -c)
    return z.at[idx].set(y.reshape(len(comps), G))


_dfe_jit = jax.jit(lambda pp, uu: _linear_eq(jnp.zeros(G), jnp.zeros(G), pp, ["S", "V"], uu))


def dfe(p, u=U0):
    return _dfe_jit(_pc(p), jnp.asarray(u))


def R_C(p, xeq=None, u=U0):
    xeq = dfe(p, u) if xeq is None else xeq
    K, F, V = ngm(xeq, p, COVID_INF, u, "covid")
    return spectral_radius(K), K


def R_H(p, xeq=None, u=U0):
    xeq = dfe(p, u) if xeq is None else xeq
    K, F, V = ngm(xeq, p, HIV_DFE, u, "hiv")
    return spectral_radius(K), K


def R0_full(p, u=U0):
    K, F, V = ngm(dfe(p, u), p, ALL_INF, u, "all")
    return spectral_radius(K)


# ------------------------------------------------------------------ exact endemic equilibria
_EQ_CACHE = {}


def _eq_funcs(kind, aidx_t):
    key = (kind, aidx_t)
    if key in _EQ_CACHE:
        return _EQ_CACHE[key]
    aidx = np.array(aidx_t, dtype=int); na = len(aidx)
    comps = {"hiv": HIV_ONLY_COMPS, "coex": ALIVE_COMPS, "covid": COVID_ONLY_COMPS}[kind]
    nC = NA * NQ

    def unpack(z):
        lamH = jnp.zeros(G).at[aidx].set(jnp.exp(z[:na]))
        lamC = jnp.zeros(G) if kind == "hiv" else jnp.repeat(jnp.exp(z[na:]), NR)
        return lamC, lamH

    def resid(z, p, u):
        lamC, lamH = unpack(z)
        x = _linear_eq(lamC, lamH, p, comps, u)
        lC, lH, _ = forces(x, u, p)
        r = jnp.log(lH[aidx] + 1e-300) - z[:na]
        if kind != "hiv":
            r = jnp.concatenate([r, jnp.log(lC.reshape(nC, NR)[:, 0]) - z[na:]])
        return r

    def state(z, p, u):
        lamC, lamH = unpack(z)
        return _linear_eq(lamC, lamH, p, comps, u)

    out = (jax.jit(resid), jax.jit(jax.jacfwd(resid)), jax.jit(state), na, nC)
    _EQ_CACHE[key] = out
    return out


def foi_equilibrium(p, kind="hiv", guess=None, u=U0):
    """Endemic equilibrium as a fixed point in the log forces of infection.
    kind = 'hiv' (lamC=0), 'covid' (lamH=0) or 'coex'. The log parametrisation
    excludes the disease-free root. Returns x, z, max|rhs|, success."""
    act = np.asarray(p["c_sex"]) > 0
    aidx = tuple(int(i) for i in np.where(act)[0]) if kind != "covid" else tuple()
    rj, Jj, st, na, nC = _eq_funcs(kind, aidx)
    pc = _pc(p); uu = jnp.asarray(u)
    if guess is None:
        guess = np.log(np.full(na, 1e-5)) if na else np.zeros(0)
        if kind != "hiv":
            guess = np.concatenate([guess, np.log(np.full(nC, 5e-3))])
    sol = _root(lambda z: np.asarray(rj(jnp.asarray(z), pc, uu)), guess,
                jac=lambda z: np.asarray(Jj(jnp.asarray(z), pc, uu)), method="hybr", tol=1e-12)
    x = st(jnp.asarray(sol.x), pc, uu)
    res = float(jnp.abs(rhs(x, uu, pc)[:NALIVE]).max())
    ok = bool(sol.success) and np.all(np.isfinite(sol.x)) and (sol.x.max() > -60 if len(sol.x) else True)
    return x, sol.x, res, ok


def hiv_equilibrium(p, guess=None):
    """HIV-only endemic equilibrium with multistart; returns (x, z) or (dfe, None)."""
    act = np.asarray(p["c_sex"]) > 0; na = int(act.sum())
    starts = ([guess] if guess is not None else []) + [np.log(np.full(na, v)) for v in (1e-5, 1e-4, 1e-6, 1e-3)]
    for g in starts:
        x, z, res, ok = foi_equilibrium(p, "hiv", g)
        if ok and res < 1e-14 and float(plhiv(x).sum()) > 1e-12:
            return x, z
    return dfe(p), None


def coex_equilibrium(p, zH=None, zE=None):
    """HIV--COVID coexistence equilibrium (warm-started from the HIV-only one)."""
    if zE is None:
        if zH is None:
            xH, zH = hiv_equilibrium(p)
        act = np.asarray(p["c_sex"]) > 0
        zE = np.concatenate([zH, np.log(np.full(NA * NQ, 5e-3))])
    x, z, res, ok = foi_equilibrium(p, "coex", zE)
    return x, z, res, ok


# ------------------------------------------------------------------ integration and summaries
def run(x0, p, days, dt, u=U0, scheme="rk4"):
    n = int(round(days / dt))
    Us = jnp.tile(u, (n, 1))
    return rk4_path(x0, Us, p, dt) if scheme == "rk4" else nsfd_path(x0, Us, p, dt)


run_jit = jax.jit(run, static_argnums=(2, 3, 5))


def adult_prev(x, ages=(1, 2)):
    m = np.zeros((NA, NQ, NR), bool)
    for a in ages:
        m[a] = True
    m = jnp.asarray(m.reshape(G))
    return float((plhiv(x) * m).sum() / (alive(x) * m).sum())


def kp_prev(x):
    m = jnp.asarray(KPMASK)
    return float((plhiv(x) * m).sum() / (alive(x) * m).sum())


def art_cov(x):
    return float(on_art(x).sum() / plhiv(x).sum())


def jac_alive(x, p, u=U0, comps=None):
    comps = ALIVE_COMPS if comps is None else comps
    idx = jnp.array([IDX[k] for k in comps])
    def f(y):
        return rhs(x.at[idx].set(y.reshape(len(comps), G)), u, p)[idx].reshape(-1)
    return np.asarray(jax.jacfwd(f)(x[idx].reshape(-1)))


def immune_escape(x, chi=0.5):
    """Remove a fraction chi of SARS-CoV-2 protection; reset counters."""
    x = jnp.asarray(x)
    for a, b in [("R", "S"), ("V", "S"), ("LR", "L"), ("TR", "T"), ("UR", "U")]:
        mv = chi * x[IDX[a]]
        x = x.at[IDX[a]].add(-mv).at[IDX[b]].add(mv)
    for k in ["Dcov", "Dhiv", "IncH", "IncC"]:
        x = x.at[IDX[k]].set(0.)
    return x
