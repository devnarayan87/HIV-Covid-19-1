"""Writes manuscript/numbers.tex and the table bodies from results/*.json.
Every number quoted in the manuscript is a macro defined here."""
import json, os, glob, re
import numpy as np

R = lambda f: json.load(open(os.path.join("results", f)))
A = R("A_thresholds.json"); B = R("B_thresholds.json"); C = R("C_scenarios.json")["scenarios"]
NM = R("C_scenarios.json")["names"]
D = R("D_nsfd.json"); F = R("F_control.json"); V = R("verify_math.json"); H = R("H_gas.json")
cal = R("calibration.json"); prim = R("calibrated_primitive.json")
E = R("E_uncertainty.json") if os.path.exists("results/E_uncertainty.json") else None
G = R("G_robustness.json") if os.path.exists("results/G_robustness.json") else None
M = {}
f0 = lambda v: f"{v:.0f}"; f1 = lambda v: f"{v:.1f}"; f2 = lambda v: f"{v:.2f}"; f3 = lambda v: f"{v:.3f}"
def sci(v, d=1):
    if v == 0: return "0"
    e = int(np.floor(np.log10(abs(v)))); m = v / 10 ** e
    return f"{m:.{d}f}\\times10^{{{e}}}"
def big(v): return f"{v:,.0f}".replace(",", "{,}")

# ---- calibration
M["valBetaC"] = f"{cal['betaC']:.4f}"; M["valBetaH"] = f"{cal['betaH']:.4f}"
M["valTauYears"] = f1(1 / cal["tau"] / 365)
M["valCalPrev"] = f"{100 * cal['adult_prev_coex']:.4f}"; M["valCalArt"] = f"{100 * cal['art_coex']:.4f}"
M["valCalResPrev"] = sci(abs(cal["resid_coex"][0])); M["valCalResArt"] = sci(abs(cal["resid_coex"][1]))
M["valCalIter"] = str(cal["iterations"]); M["valCalTime"] = f0(cal.get("time_s", 0))
M["valEqResE"] = sci(cal["rhs_max_coex"]); M["valEqResH"] = sci(cal["rhs_max_hivonly"])
M["valKPprev"] = f1(100 * cal["kp_prev_coex"])
# ---- thresholds
M["valRC"] = f2(A["R_C"]); M["valRH"] = f3(A["R_H"]); M["valRzero"] = f2(A["R0_full"])
M["valRCH"] = f3(A["R_C_at_HIV_eq"]); M["valRHC"] = f3(A["R_H_at_COVID_eq"])
M["valTKP"] = f3(A["T_KP"]); M["valRHlow"] = f3(A["R_H_lowrisk_only"]); M["valRHkp"] = f3(A["R_H_KP_only"])
M["valTKPpct"] = f1(100 * (1 - 1 / A["T_KP"]))
for k, n in [("E", "valIdxE"), ("CL", "valIdxCL"), ("CU", "valIdxCU"), ("CT", "valIdxCT")]:
    M[n] = f2(A[f"index_{k}_mean"])
M["valHIVinc"] = f1(A["hiv_incidence_per_100k_yr"]); M["valAIDSmort"] = f1(A["aids_deaths_per_100k_yr"])
M["valEndemicCovidDeaths"] = f1(A["covid_deaths_per_100k_yr"])
M["valPLHIVpct"] = f2(100 * A["plhiv_frac"])
M["valCoexEig"] = sci(A["coex_max_re_eig"]); M["valInvEig"] = f3(A["hivonly_max_re_eig_full"])
M["valRelaxYears"] = f0(A["relaxation_years_hiv"])
Rm = np.array(A["RC_strata"])
M["valRCmax"] = f2(Rm.max()); M["valRCQone"] = f2(Rm[:, 0].mean()); M["valRCQfour"] = f2(Rm[:, 3].mean())
M["valRCminStrat"] = f2(Rm.min())
kp = A["kp_share_by_age"]
M["valKPshareA"], M["valKPshareB"], M["valKPshareC"], M["valKPshareD"] = [f1(100 * v) for v in kp[1:]]
M["valAgeShares"] = ", ".join(f0(100 * v) for v in A["age_share"])
# ---- B
M["valArtThresh"] = f1(100 * (B["art_mult_threshold"] - 1)) if B["art_mult_threshold"] else "--"
M["valPrevThresh"] = f1(100 * B["prev_threshold"])
M["valRHxiHalf"] = f3(B["RH_xi_half"]); M["valRHdisrupt"] = f3(B["RH_art_disrupt"])
M["valRHmonotone"] = "verified on a grid of 60 values from 0.25 to 40 times the baseline rate" if B["RH_monotone_decreasing_in_tau"] else "not monotone"
M["valRCmin"] = f2(B["RC_min_on_grid"])
M["valBifAbsC"] = sci(B["bif_checks"]["covid_endemic_max_abscissa"])
M["valBifAbsH"] = sci(B["bif_checks"]["hiv_endemic_max_abscissa"])
# ---- elasticities from the robustness baseline
if G:
    el = G["baseline"]["elasticities"]
    M["valElTau"] = f2(el["RH_tau"]); M["valElXi"] = f2(el["RH_xi"]); M["valElOmega"] = f2(el["RH_omega"])
# ---- GAS
M["valRCtildeRatio"] = f3(H["R_C_tilde_over_R_C"]); M["valRCtildeGap"] = f1(100 * (H["R_C_tilde_over_R_C"] - 1))
M["valRHagg"] = f3(H["R_H_aggregated"])
M["valHatRH"] = sci(H["hatR_H"], 0); M["valHatRC"] = sci(H["hatR_C"], 0)
# ---- verification table
M["valVOne"] = sci(V["V1_max_rel_diff_paper_vs_code"])
M["valVTwoCons"] = sci(V["V2_conservation_max_abs"]); M["valVTwoBal"] = sci(V["V2_partnership_balance_max"])
M["valVTwoRec"] = sci(V["V2_contact_reciprocity_max"])
M["valVFour"] = sci(max(r[3] for r in V["V4_R0_vs_max"]))
M["valVFive"] = f"{V['V5_rho_rows_scaled_at_cstar']:.12f}"
v6 = V["V6"]
M["valVSixA"] = f"{v6['xH_full_abscissa']:.6f} vs {v6['s(F-V)_covid_at_xH']:.6f}"
M["valVSixB"] = f"${sci(v6['xC_full_abscissa'], 4)}$ vs ${sci(v6['s(F-V)_hiv_at_xC'], 4)}$"
M["valVSevenInf"] = sci(max(r[0] for r in V["V7_random_ic_R09_final_infected_and_dist"]))
M["valVEight"] = sci(max(r[0] for r in V["V8_random_ic_to_coex"]))
M["valNsfdOrder"] = f2(D["nsfd_order"]); M["valEulerOrder"] = f2(D["euler_order"]); M["valRKOrder"] = f2(D["rk4_order"])
M["valFixedDrift"] = sci(max(r["max_rel_drift"] for r in D["fixed_points"]))
M["valGradErr"] = sci(max(min(r["rel_err"] for r in F["gradient_check"] if r["trial"] == t) for t in range(4)))
lb = F["lbfgsb"]
M["valLbfgsDiff"] = f"${sci(lb['rel_diff_J'])}$ (L-BFGS-B {'higher' if lb['rel_diff_J'] > 0 else 'lower'})"
M["valLbfgsDiffPct"] = f"{100 * abs(lb['rel_diff_J']):.2g}\\,\\%"
M["valPmpRes"] = sci(F["runs"]["Integrated syndemic package"]["pmp_residual"])
# ---- wave and scenarios
S0 = C["S0"]
M["valWaveInf"] = big(S0["covid_infections_per100k"]); M["valWaveDeaths"] = f1(S0["covid_deaths_per100k"])
M["valPeakH"] = f1(S0["peak_hosp_per100k"]); M["valPeakDay"] = f0(S0["peak_day"])
ag = S0["mort_by_age_per100k"]; M["valMortOld"] = f0(ag[4]); M["valMortYoung"] = f2(ag[1])
M["valPLHIVdeaths"] = f1(S0["covid_deaths_PLHIV_per100k_PLHIV"]); M["valNegDeaths"] = f1(S0["covid_deaths_HIVneg_per100k"])
M["valIFRratio"] = f2(S0["IFR_ratio_PLHIV_agestd"])
q = S0["mort_by_quartile_agestd_per100k"]; M["valMortQone"] = f1(q[0]); M["valMortQfour"] = f1(q[3])
M["valRRQ"] = f2(S0["RR_Q1_Q4"]); M["valGapQ"] = f1(S0["gap_Q1_Q4_per100k"]); M["valCI"] = f3(S0["concentration_index"])
M["valDisruptHIV"] = f2(C["S1"]["new_hiv_per100k"] - S0["new_hiv_per100k"])
M["valDisruptHIVpct"] = f0(100 * (C["S1"]["new_hiv_per100k"] / S0["new_hiv_per100k"] - 1))
M["valDisruptAIDS"] = f2(C["S1"]["aids_deaths_per100k"] - S0["aids_deaths_per100k"])
M["valRapidHIVpct"] = f0(100 * (1 - C["S2"]["new_hiv_per100k"] / S0["new_hiv_per100k"]))
M["valRapidAIDS"] = f2(S0["aids_deaths_per100k"] - C["S2"]["aids_deaths_per100k"])
M["valDoses"] = big(C["S3"]["extra_doses_per100k"])
for key, s in [("Uniform", "S3"), ("Old", "S4"), ("Dep", "S6"), ("PU", "S7"), ("PUplus", "S8")]:
    M[f"val{key}Avert"] = f2(C[s]["covid_deaths_averted_per100k"]); M[f"val{key}RR"] = f2(C[s]["RR_Q1_Q4"])
M["valPUplusPLHIV"] = f1(C["S8"]["covid_deaths_PLHIV_per100k_PLHIV"])
M["valOldGap"] = f1(C["S4"]["gap_Q1_Q4_per100k"]); M["valPUGap"] = f1(C["S7"]["gap_Q1_Q4_per100k"])
M["valIncExcess"] = f0(100 * (A["hiv_incidence_per_100k_yr"] / (64500 / 1.45e9 * 1e5) - 1))
M["valIsoPeakPct"] = f0(100 * (1 - C["S9"]["peak_hosp_per100k"] / S0["peak_hosp_per100k"]))
M["valIsoAvert"] = f2(C["S9"]["covid_deaths_averted_per100k"]); M["valCareAvert"] = f1(C["S10"]["covid_deaths_averted_per100k"])
M["valIntAvert"] = f1(C["S11"]["covid_deaths_averted_per100k"])
M["valIntPct"] = f0(100 * C["S11"]["covid_deaths_averted_per100k"] / S0["covid_deaths_per100k"])
M["valIntPLHIV"] = f1(C["S11"]["covid_deaths_PLHIV_per100k_PLHIV"]); M["valIntHIV"] = f2(C["S11"]["new_hiv_per100k"])
M["valIntRR"] = f2(C["S11"]["RR_Q1_Q4"])
# ---- optimal control
r = F["runs"]
def m(k, f): return r[k]["metrics"][f]
for key, nm in [("None", "No control"), ("Cov", "COVID-only package"), ("Hiv", "HIV-only package"),
                ("Int", "Integrated syndemic package"), ("Eq", "Integrated, equity-weighted")]:
    M[f"valOC{key}Deaths"] = f1(m(nm, "covid_deaths")); M[f"valOC{key}HIV"] = f2(m(nm, "new_hiv"))
    M[f"valOC{key}AIDS"] = f2(m(nm, "aids_deaths")); M[f"valOC{key}RR"] = f2(m(nm, "RR_Q1_Q4"))
    M[f"valOC{key}Doses"] = big(m(nm, "doses")); M[f"valOC{key}Peak"] = f1(m(nm, "peak_hosp"))
    M[f"valOC{key}Qone"] = f1(m(nm, "mort_q_agestd")[0])
    M[f"valOC{key}J"] = f1(r[nm]["J"])
    if nm != "No control":
        M[f"valOC{key}Iter"] = str(r[nm]["iters"])
vq = r["Integrated syndemic package"]["vac_first60_by_quartile"]
M["valOCvacQone"] = f2(vq[0]); M["valOCvacQfour"] = f2(vq[3])
M["valOCBhalf"] = f1(F["B_sensitivity"]["0.5"]["metrics"]["covid_deaths"])
M["valOCBdouble"] = f1(F["B_sensitivity"]["2.0"]["metrics"]["covid_deaths"])
# ---- uncertainty ensemble
nice = {"betaC": r"$\beta_C$", "RC_target": r"$\mathcal{R}_C$", "rho": r"$p_a$", "gamma": r"$\gamma$", "iota1": r"$\iota_1$",
        "iotaC": r"$\iota_C$", "epsV": r"$\epsilon_V$", "epsSev": r"$\epsilon_{\mathrm{sev}}$", "epsP": r"$\epsilon_P$",
        "eta": r"$\eta$", "eps": r"$\zeta$", "epsPw": r"$\varpi$", "hosp_mult": r"$p^{\mathrm{hosp}}$ scale",
        "fH_mult": r"$f^H$ scale", "HR_L": r"$\mathrm{HR}_L$", "HR_U": r"$\mathrm{HR}_U$", "HR_T": r"$\mathrm{HR}_T$",
        "gCL": r"$\gamma_{CL}$", "gCU": r"$\gamma_{CU}$", "gCT": r"$\gamma_{CT}$", "chi": r"$f_{\mathrm{esc}}$",
        "g_crowd": r"$g_{\mathrm{crowd}}$", "g_vac": r"$g_{\mathrm{vac}}$", "g_art": r"$g_{\mathrm{art}}$", "g_fatal": r"$g_{\mathrm{fatal}}$",
        "assort_C": r"$\varsigma_C$", "omega": r"$\omega$", "muU": r"$\mu_U$", "xi": r"$\xi$", "tauU_mult": r"$m_\tau$",
        "kappaU": r"$\kappa_U$", "epsT": r"$\kappa_T$", "theta": r"$\theta$", "c_high": r"$c_{\mathrm{hi}}$",
        "eps_risk": r"$\varsigma_{\mathrm{risk}}$", "act_lo": r"$c_{\mathrm{lo}}$", "kp_dur": r"$1/k_{\mathrm{out}}$",
        "kp_mult": r"$s_{in}$ scale", "psi": r"$\psi$", "iso_eff": r"$e_{\mathrm{iso}}$"}
if E:
    s = E["summary"]
    M["valEnsN"] = str(E["n_total"]); M["valEnsOK"] = str(E["n_ok"])
    M["valEnsMaxRes"] = sci(s["calib_max_resid"]["max"])
    def ci(k, fmt=f1):
        return fmt(s[k]["median"]), fmt(s[k]["q025"]), fmt(s[k]["q975"])
    M["valUAdeathsMed"], M["valUAdeathsLo"], M["valUAdeathsHi"] = ci("deaths_S0")
    M["valUAplMed"], M["valUAplLo"], M["valUAplHi"] = ci("plhiv_deaths_S0", f0)
    M["valUAifrMed"], M["valUAifrLo"], M["valUAifrHi"] = ci("IFR_ratio", f2)
    M["valUArhMed"], M["valUArhLo"], M["valUArhHi"] = ci("R_H", f3)
    M["valUArhLo"] = f3(s["R_H"]["min"]); M["valUArhHi"] = f3(s["R_H"]["max"])
    M["valEnsDisruptLo"] = f0(s["disrupt_extra_hiv_pct"]["q025"]); M["valEnsDisruptHi"] = f0(s["disrupt_extra_hiv_pct"]["q975"])
    pr = E["ranking_probabilities"]
    pct = lambda k: f0(100 * pr[k])
    M["valPrDisrupt"] = pct("S1_more_hiv_than_S0"); M["valPrOld"] = pct("S4_more_than_S3")
    M["valPrPUeff"] = pct("S7_vs_S4_deaths_within_5pct"); M["valPrPUeq"] = pct("S7_RR_lower_than_S4")
    M["valPrPLHIV"] = pct("S8_PLHIV_lower_than_S7"); M["valPrPLHIVcost"] = pct("S8_deaths_within_1pct_of_S7")
    M["valPrCare"] = pct("S10_more_than_S9"); M["valPrOldWiden"] = pct("S4_RR_higher_than_S0")
    # best vaccination rule by deaths averted (S3-S8) per sample
    recs = [json.load(open(f_)) for f_ in sorted(glob.glob("results/ensemble/sample_*.json"))]
    recs = [x for x in recs if x.get("ok")]
    vk = ["S3", "S4", "S5", "S6", "S7", "S8"]
    best = [vk[int(np.argmax([x["scenarios"][k]["covid_deaths_averted_per100k"] for k in vk]))] for x in recs]
    cnt = {k: best.count(k) for k in vk}
    kb = max(cnt, key=cnt.get)
    vnames = {"S3": "uniform allocation", "S4": "age priority (S4)", "S5": "PLHIV priority (S5)", "S6": "deprivation weighting (S6)",
              "S7": "proportionate universalism (S7)", "S8": "proportionate universalism with PLHIV priority (S8)"}
    second = sorted(cnt, key=cnt.get, reverse=True)[1]
    M["valBestSingle"] = (f"{vnames[kb]} ({f0(100 * cnt[kb] / len(best))}\\,\\% of samples), followed by "
                          f"{vnames[second]} ({f0(100 * cnt[second] / len(best))}\\,\\%)")
    M["valPrBestOld"] = f0(100 * cnt["S4"] / len(best))
    pc = E["prcc"]
    def top(o, k=3):
        v = np.array(pc["values"][o]); idx = np.argsort(-np.abs(v))[:k]
        return ", ".join(f"{nice[pc['params'][i]]} ({v[i]:+.2f})".replace("(-", "($-$") for i in idx)
    M["valTopDeaths"] = top("deaths_S0"); M["valTopPL"] = top("plhiv_deaths_S0"); M["valTopRR"] = top("RR_S0")
    M["valTopEq"] = top("S7_minus_S4_RR")
    # PRCC appendix table
    outs = ["R_H", "deaths_S0", "plhiv_deaths_S0", "RR_S0", "disrupt_extra_hiv_pct", "S7_minus_S4_RR"]
    hdr = ["$\\mathcal{R}_H$", "Deaths", "Deaths, PLHIV", "RR", "Disruption", "RR(S7)$-$RR(S4)"]
    rows = []
    for j, pnm in enumerate(pc["params"]):
        cells = []
        for o in outs:
            v = pc["values"][o][j]; pv = pc["pvalues"][o][j]
            cells.append((("\\textbf{%+.2f}" % v) if pv < 0.001 and abs(v) >= 0.3 else ("%+.2f" % v)).replace("-", "$-$"))
        rows.append(nice[pnm] + " & " + " & ".join(cells) + " \\\\")
    with open("manuscript/prcc_table.tex", "w") as fh:
        fh.write("\\begin{table}[h]\n\\caption{Partial rank correlation coefficients in the re-calibrated ensemble ("
                 + str(E["n_ok"]) + " samples; " + str(pc["dof"]) + " residual degrees of freedom). Bold: $|\\mathrm{PRCC}|\\ge0.3$ and $p<0.001$}\\label{tab:prcc}\n\\scriptsize\\setlength{\\tabcolsep}{3pt}\n"
                 "\\begin{tabular*}{\\textwidth}{@{\\extracolsep\\fill}l" + "r" * len(outs) + "}\n\\toprule\nInput & " + " & ".join(hdr) + " \\\\\n\\midrule\n"
                 + "\n".join(rows) + "\n\\botrule\n\\end{tabular*}\n\\end{table}\n")
# ---- structural variants
if G:
    vn = list(G.keys())
    M["valNvariants"] = str(len(vn))
    M["valRRnoGrad"] = f2(G["no deprivation gradients"]["scenarios"]["S0"]["RR_Q1_Q4"])
    M["valRRcrowd"] = f2(G["crowding gradient only"]["scenarios"]["S0"]["RR_Q1_Q4"])
    M["valRRaccess"] = f2(G["access gradients only"]["scenarios"]["S0"]["RR_Q1_Q4"])
    M["valRRfatal"] = f2(G["fatality gradient only"]["scenarios"]["S0"]["RR_Q1_Q4"])
    M["valRHold"] = f3(G["2023 HIV targets (0.22 %, 69 %)"]["R_H"])
    best_pu = sum(1 for k in vn if min(G[k]["scenarios"][s_]["RR_Q1_Q4"] for s_ in ["S7", "S8"]) <= min(G[k]["scenarios"][s_]["RR_Q1_Q4"] for s_ in ["S3", "S4", "S5", "S6"]))
    M["valAvNoGradOld"] = f2(G["no deprivation gradients"]["scenarios"]["S4"]["covid_deaths_averted_per100k"])
    M["valAvNoGradPU"] = f2(G["no deprivation gradients"]["scenarios"]["S7"]["covid_deaths_averted_per100k"])
    M["valAvDblOld"] = f2(G["doubled deprivation gradients"]["scenarios"]["S4"]["covid_deaths_averted_per100k"])
    M["valAvDblPU"] = f2(G["doubled deprivation gradients"]["scenarios"]["S7"]["covid_deaths_averted_per100k"])
    M["valRRdbl"] = f2(G["doubled deprivation gradients"]["scenarios"]["S0"]["RR_Q1_Q4"])
    M["valRRnoGradPU"] = f2(G["no deprivation gradients"]["scenarios"]["S7"]["RR_Q1_Q4"])
    M["valNvarPUbest"] = str(best_pu)
    rows = []
    for k in vn:
        g_ = G[k]; sc_ = g_["scenarios"]
        rows.append(f"{k.replace('%', chr(92) + '%').replace('R_C', '$' + chr(92) + 'mathcal{R}_C$')} & {g_['R_H']:.3f} & {sc_['S0']['covid_deaths_per100k']:.1f} & "
                    f"{sc_['S0']['RR_Q1_Q4']:.2f} & {sc_['S4']['RR_Q1_Q4']:.2f} & {sc_['S7']['RR_Q1_Q4']:.2f} & "
                    f"{sc_['S4']['covid_deaths_averted_per100k']:.2f} & {sc_['S7']['covid_deaths_averted_per100k']:.2f} \\\\")
    open("manuscript/robust_table.tex", "w").write("\n".join(rows) + "\n\\botrule\n")
# ---- scenario table
rows = []
for k, v in C.items():
    rows.append(f"{k} & {NM[k]} & {v['covid_deaths_per100k']:.1f} & {v['covid_deaths_averted_per100k']:.2f} & "
                f"{v['covid_deaths_PLHIV_per100k_PLHIV']:.1f} & {v['peak_hosp_per100k']:.1f} & {v['new_hiv_per100k']:.2f} & "
                f"{v['aids_deaths_per100k']:.2f} & {v['RR_Q1_Q4']:.2f} & {v['concentration_index']:.3f} \\\\")
open("manuscript/scenario_table.tex", "w").write("\n".join(rows) + "\n\\botrule\n")
with open("manuscript/numbers.tex", "w") as fh:
    for k, v in M.items():
        fh.write(f"\\newcommand{{\\{k}}}{{{v}}}\n")
# ---- report macros used but undefined
used = set()
for f_ in glob.glob("manuscript/*.tex"):
    if f_.endswith("numbers.tex"): continue
    used |= set(re.findall(r"\\(val[A-Za-z]+)", open(f_).read()))
missing = sorted(u for u in used if u not in M)
print(len(M), "macros written; missing:", missing)
