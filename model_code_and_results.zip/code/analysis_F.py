"""Optimal control: FBSM with exact discrete adjoint, verified by (i) finite-difference
gradient checks, (ii) the discrete Pontryagin residual, (iii) an independent L-BFGS-B
solution of the same discrete problem, and (iv) sensitivity to control costs.
Writes results/F_control.json and results/F_controls.npz."""
import json, time
import numpy as np
import jax, jax.numpy as jnp
from common import *
from control import fbsm, make_problem, total_objective, pmp_residual, lbfgsb

p = P(); xH, xE, zH, zE = equilibria()
x0 = immune_escape(xE, chi=0.5)
T, dt = 730.0, 0.5
n = int(T / dt)
tg = np.arange(n) * dt
W_eq = {"death": 1.0, "hiv": 1.0, "bed": 0.01, "ses_w": np.ones(NQ)}
W_eqty = {**W_eq, "ses_w": np.array([1.6, 1.25, 1.0, 0.8])}
B = np.array([0.015, 0.015, 0.015, 0.015, 0.15, 0.03, 0.12, 0.05])
PACKAGES = {"COVID-only package": np.array([1, 1, 1, 1, 0, 0, 1, 1], bool),
            "HIV-only package": np.array([0, 0, 0, 0, 1, 1, 0, 0], bool),
            "Integrated syndemic package": np.ones(NCTRL, bool)}


@jax.jit
def sim(U):
    return rk4_path(x0, U, p, dt)


def metrics(U):
    xs = sim(U); xT = xs[-1]; N0 = np.asarray(p["N0"])
    vac, vacP, *_ = jax.vmap(lambda u: rates(p, u))(U)
    doses = dt * jnp.sum(vac * xs[:-1, IDX["S"]] + vacP * (xs[:-1, IDX["L"]] + xs[:-1, IDX["T"]] + xs[:-1, IDX["U"]]))
    dqa = np.asarray(xT[IDX["Dcov"]]).reshape(NA, NQ, NR).sum(2); nqa = N0.reshape(NA, NQ, NR).sum(2)
    agew = np.asarray(p["age_share"]); rate = (agew[:, None] * dqa / nqa).sum(0)
    return {"covid_deaths": float(1e5 * xT[IDX["Dcov"]].sum()), "aids_deaths": float(1e5 * xT[IDX["Dhiv"]].sum()),
            "new_hiv": float(1e5 * xT[IDX["IncH"]].sum()), "peak_hosp": float(1e5 * xs[:, IDX["H"]].sum(1).max()),
            "doses": float(1e5 * doses), "mort_q_agestd": (1e5 * rate).tolist(), "RR_Q1_Q4": float(rate[0] / rate[-1]),
            "gap_Q1_Q4": float(1e5 * (rate[0] - rate[-1]))}


out = {"weights": {k: (v.tolist() if isinstance(v, np.ndarray) else v) for k, v in W_eq.items()}, "B": B.tolist(), "runs": {}}
# ---- (i) finite-difference check of the discrete-adjoint gradient
J, dJ, gs = total_objective(x0, p, W_eq, B, dt, n, np.ones(NCTRL, bool))
rng = np.random.default_rng(3)
fd = []
for trial in range(4):
    U = jnp.asarray(rng.uniform(0.2, 0.8, (n, NCTRL)))
    d = jnp.asarray(rng.choice([-1.0, 1.0], (n, NCTRL)) * rng.uniform(0.5, 1.0, (n, NCTRL)))
    g = float(jnp.sum(dJ(U) * d))
    for eps in [1e-3, 1e-4, 1e-5]:
        num = (J(U + eps * d) - J(U - eps * d)) / (2 * eps)
        fd.append({"trial": trial, "eps": eps, "adjoint": g, "fd": num, "rel_err": abs(num - g) / abs(g)})
out["gradient_check"] = fd
print("gradient check: min rel err per trial", [min(r["rel_err"] for r in fd if r["trial"] == t_) for t_ in range(4)], flush=True)
# ---- (ii) packages by FBSM
Z = jnp.zeros((n, NCTRL))
out["runs"]["No control"] = {"metrics": metrics(Z), "J": J(Z)}
store = {}
for name, act in list(PACKAGES.items()) + [("Integrated, equity-weighted", np.ones(NCTRL, bool))]:
    Wt = W_eqty if "equity" in name else W_eq
    t0 = time.time()
    U, hist, Js, Jc = fbsm(x0, p, Wt, B, T=T, dt=dt, active=act, relax=0.5, tol=1e-5, maxit=400)
    Jw, dJw, gsw = total_objective(x0, p, Wt, B, dt, n, act)
    res = pmp_residual(U, gsw(U), B, dt, act)
    out["runs"][name] = {"metrics": metrics(U), "J_state": Js, "J_control": Jc, "J": Js + Jc, "iters": len(hist),
                         "final_rel_change": hist[-1][2], "pmp_residual": res, "time_s": time.time() - t0,
                         "monotone_J": bool(np.all(np.diff([h[1] for h in hist]) <= 1e-9)),
                         "hist": [[h[0], h[1], h[2]] for h in hist]}
    store[name] = np.asarray(U)
    print(name, out["runs"][name]["metrics"]["covid_deaths"], out["runs"][name]["metrics"]["new_hiv"],
          "iters", len(hist), "J", Js + Jc, "pmp", res, flush=True)
# J of "no control" in the equity-weighted functional
Jq, _, _ = total_objective(x0, p, W_eqty, B, dt, n, np.ones(NCTRL, bool))
out["runs"]["No control"]["J_equity"] = Jq(Z)
# ---- (iii) independent solver on the integrated problem
t0 = time.time()
U_lb, sol, J_lb = lbfgsb(x0, p, W_eq, B, T=T, dt=dt, maxiter=600)
U_fb = jnp.asarray(store["Integrated syndemic package"])
out["lbfgsb"] = {"J": J_lb, "J_fbsm": out["runs"]["Integrated syndemic package"]["J"],
                 "rel_diff_J": (J_lb - out["runs"]["Integrated syndemic package"]["J"]) / abs(J_lb),
                 "max_abs_control_diff": float(jnp.max(jnp.abs(U_lb - U_fb))),
                 "mean_abs_control_diff": float(jnp.mean(jnp.abs(U_lb - U_fb))),
                 "pmp_residual_lbfgsb": pmp_residual(U_lb, gs(U_lb), B, dt, np.ones(NCTRL, bool)),
                 "nit": int(sol.nit), "message": str(sol.message), "time_s": time.time() - t0}
print("L-BFGS-B", out["lbfgsb"], flush=True)
# ---- (iv) sensitivity of the integrated solution to control costs
sens = {}
for fac in [0.5, 2.0]:
    U, hist, Js, Jc = fbsm(x0, p, W_eq, B * fac, T=T, dt=dt, relax=0.5, tol=1e-5, maxit=400)
    m = metrics(U)
    Ua = np.asarray(U)
    sens[str(fac)] = {"metrics": m, "iters": len(hist),
                      "vac_first60_by_quartile": Ua[:120, :4].mean(0).tolist(),
                      "mean_controls": Ua.mean(0).tolist()}
    store[f"Integrated_B_x{fac}"] = Ua
    print("B x", fac, m["covid_deaths"], m["new_hiv"], Ua[:120, :4].mean(0), flush=True)
out["B_sensitivity"] = sens
for name in ["Integrated syndemic package", "Integrated, equity-weighted"]:
    Ua = store[name]
    out["runs"][name]["vac_first60_by_quartile"] = Ua[:120, :4].mean(0).tolist()
    out["runs"][name]["mean_controls"] = Ua.mean(0).tolist()
np.savez("results/F_controls.npz", t=tg, U_lbfgsb=np.asarray(U_lb),
         **{k.replace(" ", "_").replace(",", ""): v for k, v in store.items()})
xs0 = sim(Z); xs1 = sim(U_fb)
sel = slice(0, n + 1, 4)
traj = {"t": (np.arange(n + 1) * dt)[sel].tolist()}
for lab, xs in [("unc", xs0), ("opt", xs1)]:
    traj[lab + "_H"] = (1e5 * np.asarray(xs[sel, IDX["H"]].sum(1))).tolist()
    traj[lab + "_C"] = (1e5 * np.asarray((xs[sel, IDX["CL"]] + xs[sel, IDX["CU"]] + xs[sel, IDX["CT"]]).sum(1))).tolist()
    traj[lab + "_I"] = (1e5 * np.asarray(sum(xs[sel, IDX[k]] for k in ["E", "EV", "A", "I"]).sum(1))).tolist()
out["traj"] = traj
json.dump(out, open("results/F_control.json", "w"), indent=1)
print("done")
