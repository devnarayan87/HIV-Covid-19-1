"""Quantities in the global-stability theorem (results/H_gas.json):
R_C_tilde: SARS-CoV-2 NGM with every susceptible counted in E (numerator N*) and
           vaccinated numerator (1-eps_V) V^+, where V^+ solves 0 = nu N* - (eta+mu) V + A V;
R_H_agg:   HIV NGM of the COVID-status-aggregated system (must equal R_H).
Also the conservative lower bound N_low (maximal disease mortality) and the resulting
hat-R values, and checks of the hypotheses (H1)-(H2)."""
import json
import numpy as np
import jax.numpy as jnp
from common import *
from repro import _pc

p = P(); out = {}
x0 = dfe(p)
N0 = np.asarray(p["N0"])
# V^+ : vaccinated bound with nu acting on the whole stratum population
pp = {k: (np.asarray(v) if isinstance(v, jnp.ndarray) else v) for k, v in p.items()}
Pf, Qf = demography_operator(np.eye(G), pp, as_matrix=True)
nu = np.asarray(p["nu0"] * p["vac_access"] * p["vac_w"])
Mv = Pf - np.diag(Qf + np.asarray(p["mu"]) + float(p["eta"]))
Vplus = -np.linalg.solve(Mv, nu * N0)
out["Vplus_over_N_max"] = float(np.max(Vplus[N0 > 0] / N0[N0 > 0]))
out["V0_over_N_max"] = float(np.max(np.asarray(x0[IDX["V"]])[N0 > 0] / N0[N0 > 0]))
# F at the DFE, then rescale rows of E (numerator S0 -> N*) and E^V (V0 -> V^+)
K, F, V = ngm(x0, p, COVID_INF, U0, "covid")
S0 = np.asarray(x0[IDX["S"]]); V0 = np.asarray(x0[IDX["V"]])
rE = np.where(S0 > 0, N0 / np.maximum(S0, 1e-300), 0.0)
rV = np.where(V0 > 0, Vplus / np.maximum(V0, 1e-300), 0.0)
Ft = F.copy()
iE = COVID_INF.index("E"); iEV = COVID_INF.index("EV")
Ft[iE * G:(iE + 1) * G, :] *= rE[:, None]
Ft[iEV * G:(iEV + 1) * G, :] *= rV[:, None]
out["R_C"] = spectral_radius(K)
out["R_C_tilde"] = spectral_radius(Ft @ np.linalg.inv(V))
out["R_C_tilde_over_R_C"] = out["R_C_tilde"] / out["R_C"]
# aggregated HIV system (Z_L, Z_T, Z_U) built from the 6-class NGM by summing L+L^R etc.
Kh, Fh, Vh = ngm(x0, p, HIV_DFE, U0, "hiv")
A = np.zeros((3 * G, 6 * G))
for j, c in enumerate(HIV_DFE):            # L,T,U,LR,TR,UR -> L,T,U
    k = "LTU".index(c[0])
    A[k * G:(k + 1) * G, j * G:(j + 1) * G] = np.eye(G)
out["R_H"] = spectral_radius(Kh)
# aggregated system: L,L^R columns have identical infectivity, so F_agg = A F[:, (L,T,U)];
# V_agg is the (L,T,U) block without the internal vaccination flux nu^P to protected copies
Fagg = A @ Fh[:, :3 * G]
vacP = np.asarray(p["nu0"] * p["vac_access"] * p["vac_w"] * p["plhiv_vac_mult"])
Vagg = Vh[:3 * G, :3 * G] - np.kron(np.eye(3), np.diag(vacP))
out["R_H_aggregated"] = spectral_radius(Fagg @ np.linalg.inv(Vagg))
# conservative lower bound N_low: everybody exposed to the largest disease death rate of the stratum
dCL, dCU, dCT = [np.asarray(v) for v in co_death_rates(p)]
dbar = np.max(np.stack([np.asarray(p["dH"]), dCL, dCU + float(p["muU"]), dCT + float(p["muT"]),
                        np.full(G, float(p["muU"])), np.full(G, float(p["muT"]))]), axis=0)
Mlow = Pf - np.diag(Qf + np.asarray(p["mu"]) + dbar)
Nlow = -np.linalg.solve(Mlow, np.asarray(p["Lambda"]))
out["Nlow_over_Nstar_min"] = float(np.min((Nlow / np.maximum(N0, 1e-300))[N0 > 1e-12]))
sH = np.where(Nlow > 0, N0 / np.maximum(Nlow, 1e-300), 1.0)
Ncs = N0.reshape(NA * NQ, NR).sum(1); Ncl = Nlow.reshape(NA * NQ, NR).sum(1)
sC = np.repeat(Ncs / Ncl, NR)
# denominators enter through the infectious (source) columns
out["hatR_H"] = spectral_radius(Fagg @ np.kron(np.eye(3), np.diag(sH)) @ np.linalg.inv(Vagg))
out["hatR_C"] = spectral_radius(Ft @ np.kron(np.eye(len(COVID_INF)), np.diag(sC)) @ np.linalg.inv(V))
# hypotheses
out["H1_theta"] = float(p["theta"])
out["H2_iota1"] = float(p["iota1"])
out["H2_bound"] = float(np.min((p["gamma"] + np.asarray(p["mu"])) / (p["gamma"] + np.asarray(p["delta"]) + np.asarray(p["mu"]))))
json.dump(out, open("results/H_gas.json", "w"), indent=1)
print(json.dumps(out, indent=1))
