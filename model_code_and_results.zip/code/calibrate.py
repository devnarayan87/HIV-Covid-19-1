"""Calibration.

Targets (India HIV Estimates 2025, year 2024): adult HIV prevalence 0.20 %
(model ages 15-44 approximate the reported 15-49); 72.6 % of PLHIV virally
suppressed on ART (85 % know status x 88 % on ART x 97 % suppressed); SARS-CoV-2
basic reproduction number R_C = 3 (scenario assumption). Free parameters:
beta_C, beta_H, tau_0.

Targets are matched at the HIV--SARS-CoV-2 coexistence equilibrium, i.e. the
state from which all scenarios start. Algorithm: (1) beta_C from the linear
relation R_C proportional to beta_C; (2) 2-D Newton for (log beta_H, log tau_0)
at the HIV-only equilibrium (cheap); (3) quasi-Newton correction of the same
two unknowns at the coexistence equilibrium, reusing the step-(2) Jacobian.
"""
import json, sys, time
import numpy as np
import jax.numpy as jnp
from model import *
from repro import *

TARGETS = {"adult_prev": 0.0020, "art": 0.85 * 0.88 * 0.97, "RC": 3.0}
TOL = 1e-6          # relative tolerance on each HIV target


def _resid(x):
    return np.array([np.log(adult_prev(x) / TARGETS["adult_prev"]), np.log(art_cov(x) / TARGETS["art"])])


def calibrate(prim, RC_target=None, z0=None, verbose=False, max_newton=25):
    """prim: primitive parameter dict. Returns (prim, derived p, diagnostics, equilibria).

    Unknowns (s, log tau_0) with beta_H = beta_H*(tau_0) (1 + e^s), where beta_H*(tau_0)
    is the threshold value (R_H is proportional to beta_H), so every iterate has R_H > 1
    and an endemic HIV equilibrium exists. Newton with backtracking at the HIV-only
    equilibrium, then quasi-Newton correction at the coexistence equilibrium."""
    RC_target = TARGETS["RC"] if RC_target is None else RC_target
    prim = dict(prim)
    p = derive(prim)
    rc, _ = R_C(p)
    prim["betaC"] = prim["betaC"] * RC_target / rc
    warm = {"zH": None}
    hist = []

    def unpack(t):
        tau = float(np.exp(t[1]))
        q1 = derive({**prim, "betaH": 1.0, "tau": tau})
        rh1 = R_H(q1)[0]                      # R_H per unit beta_H
        return (1.0 + float(np.exp(t[0]))) / rh1, tau

    def eval_hiv(t):
        bH, tau = unpack(t)
        q = derive({**prim, "betaH": bH, "tau": tau})
        x, zH = hiv_equilibrium(q, warm["zH"])
        if zH is None:
            return None, q, None
        warm["zH"] = zH
        return _resid(x), q, x

    # start: keep the baseline distance to threshold and tau
    p0 = derive({**prim})
    rh0 = R_H(p0)[0]
    th = np.array([np.log(max(rh0 - 1.0, 0.02)), np.log(prim["tau"])])
    J = None
    for it in range(max_newton):
        r, q, x = eval_hiv(th)
        if r is None:
            th[0] += 0.5; continue
        hist.append(("hiv", it, *unpack(th), r.tolist()))
        if verbose: print("hiv", it, unpack(th), r, flush=True)
        if np.max(np.abs(r)) < TOL:
            break
        h = 1e-4
        J = np.zeros((2, 2))
        for j in range(2):
            tp = th.copy(); tp[j] += h
            rp, _, _ = eval_hiv(tp)
            J[:, j] = (rp - r) / h
        step = -np.linalg.solve(J, r)
        step = np.clip(step, -3.0, 3.0)
        lam = 1.0
        while lam > 1e-4:
            rn, _, _ = eval_hiv(th + lam * step)
            if rn is not None and np.max(np.abs(rn)) < np.max(np.abs(r)):
                break
            lam /= 2
        th = th + lam * step
    # ---- stage 3: coexistence equilibrium, with beta_H measured from the HIV invasion
    # threshold at the SARS-CoV-2-only equilibrium x^C (R_H^C is proportional to beta_H)
    xC, _, _, okC = foi_equilibrium(derive(prim), "covid")
    def unpackC(t):
        tau = float(np.exp(t[1]))
        q1 = derive({**prim, "betaH": 1.0, "tau": tau})
        rhc1 = spectral_radius(ngm(xC, q1, HIV_INF, U0, "hiv")[0])
        return (1.0 + float(np.exp(t[0]))) / rhc1, tau
    zE = None
    def eval_coex(t):
        nonlocal zE
        bH, tau = unpackC(t)
        q = derive({**prim, "betaH": bH, "tau": tau})
        xH, zH = hiv_equilibrium(q, warm["zH"])
        if zH is not None:
            warm["zH"] = zH
        xE, zE_new, res, ok = coex_equilibrium(q, zH=zH, zE=zE)
        if not ok or plhiv(xE).sum() < 1e-12:
            xE, zE_new, res, ok = coex_equilibrium(q, zH=zH, zE=None)
        if ok and plhiv(xE).sum() > 1e-12:
            zE = zE_new
            return _resid(xE), (xH, xE, zH, zE_new, res)
        return None, None
    Jc = J.copy() if J is not None else None
    for it in range(15):
        r, pack = eval_coex(th)
        if r is None:
            th[0] += 0.5; continue
        hist.append(("coex", it, *unpackC(th), r.tolist()))
        if verbose: print("coex", it, unpackC(th), r, pack[4], flush=True)
        if np.max(np.abs(r)) < TOL:
            break
        if Jc is None or it >= 4:          # refresh the Jacobian at the coexistence equilibrium
            h = 1e-4; Jc = np.zeros((2, 2))
            for j in range(2):
                tp = th.copy(); tp[j] += h
                rp, _ = eval_coex(tp)
                Jc[:, j] = (rp - r) / h
        step = np.clip(-np.linalg.solve(Jc, r), -3.0, 3.0)
        lam = 1.0
        while lam > 1e-4:
            rn, _ = eval_coex(th + lam * step)
            if rn is not None and np.max(np.abs(rn)) < np.max(np.abs(r)):
                break
            lam /= 2
        th = th + lam * step
    xH, xE, zH, zE, res = pack
    unpack = unpackC
    bH, tau = unpack(th)
    prim["betaH"], prim["tau"] = bH, tau
    p = derive(prim)
    diag = {"betaC": prim["betaC"], "betaH": prim["betaH"], "tau": prim["tau"],
            "RC": R_C(p)[0], "RH": R_H(p)[0],
            "adult_prev_coex": adult_prev(xE), "art_coex": art_cov(xE), "kp_prev_coex": kp_prev(xE),
            "adult_prev_hivonly": adult_prev(xH), "art_hivonly": art_cov(xH), "kp_prev_hivonly": kp_prev(xH),
            "resid_coex": r.tolist(), "rhs_max_coex": res,
            "rhs_max_hivonly": float(jnp.abs(rhs(xH, U0, p)[:NALIVE]).max()),
            "tol": TOL, "iterations": len(hist), "history": hist, "success": bool(np.max(np.abs(r)) < TOL)}
    return prim, p, diag, (xH, xE, zH, zE)


if __name__ == "__main__":
    t0 = time.time()
    prim = primitive_parameters()
    prim, p, diag, (xH, xE, zH, zE) = calibrate(prim, verbose=True)
    diag["time_s"] = time.time() - t0
    save = {k: (v.tolist() if isinstance(v, np.ndarray) else v) for k, v in prim.items()}
    json.dump(save, open("results/calibrated_primitive.json", "w"), indent=1)
    json.dump(diag, open("results/calibration.json", "w"), indent=1)
    np.savez("results/equilibria.npz", xH=np.asarray(xH), xE=np.asarray(xE), zH=zH, zE=zE)
    print(json.dumps({k: v for k, v in diag.items() if k != "history"}, indent=1))
