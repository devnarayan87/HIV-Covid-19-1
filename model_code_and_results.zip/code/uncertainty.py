"""Calibrated uncertainty ensemble.

For each Latin-hypercube draw of the non-calibrated parameters, the model is
re-calibrated (beta_C to the sampled R_C; beta_H and tau_0 to adult HIV
prevalence 0.22 % and 69 % suppressed on ART at the coexistence equilibrium),
then thresholds, equilibrium quantities and all policy scenarios are recomputed.

Usage:  python uncertainty.py worker      (any number of workers; samples are
                                           claimed with exclusive files)
        python uncertainty.py summarise
"""
import json, os, sys, time, traceback
import numpy as np
from scipy.stats import qmc, rankdata, t as tdist

ENS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "ensemble")
NSAMP = 160
SEED = 20261016

# name: (kind, a, b)  kind 'mul' = multiplier U[a,b] of baseline, 'logmul' = log-uniform
# multiplier, 'abs' = absolute U[a,b]
SPACE = {
    "RC_target": ("abs", 2.4, 3.6),
    "rho": ("mul", 0.75, 1.25), "gamma": ("mul", 0.8, 1.2), "iota1": ("mul", 0.6, 1.4),
    "iotaC": ("mul", 0.6, 1.2), "epsV": ("mul", 0.6, 1.4), "epsSev": ("abs", 0.5, 0.85),
    "epsP": ("mul", 0.6, 1.4), "eta": ("mul", 0.6, 1.6), "eps": ("mul", 0.6, 1.6), "epsPw": ("mul", 0.6, 1.6),
    "hosp_mult": ("logmul", 0.5, 2.0), "fH_mult": ("logmul", 0.5, 2.0),
    "HR_L": ("abs", 1.2, 2.2), "HR_U": ("abs", 2.0, 4.5), "HR_T": ("abs", 1.1, 1.5),
    "gCL": ("mul", 0.7, 1.3), "gCU": ("mul", 0.7, 1.3), "gCT": ("mul", 0.7, 1.3),
    "chi": ("abs", 0.3, 0.7),
    "g_crowd": ("abs", 0.0, 2.0), "g_vac": ("abs", 0.0, 2.0), "g_art": ("abs", 0.0, 2.0), "g_fatal": ("abs", 0.0, 2.0),
    "assort_C": ("abs", 0.3, 0.7),
    "omega": ("mul", 0.7, 1.3), "muU": ("mul", 0.7, 1.3), "xi": ("mul", 0.5, 2.0), "tauU_mult": ("abs", 1.5, 3.0),
    "kappaU": ("abs", 1.0, 2.0), "epsT": ("abs", 0.0, 0.05), "theta": ("abs", 0.5, 1.0),
    "c_high": ("abs", 6.0, 15.0), "eps_risk": ("abs", 0.6, 0.95), "act_lo": ("mul", 0.5, 2.0),
    "kp_dur": ("abs", 4.0, 10.0), "kp_mult": ("abs", 0.5, 1.5),
    "psi": ("abs", 0.15, 0.45), "iso_eff": ("mul", 0.7, 1.2),
}
NAMES_P = list(SPACE)


def design():
    Z = qmc.LatinHypercube(d=len(SPACE), seed=SEED).random(NSAMP)
    return Z


def build(prim, z):
    """Map a unit-cube point to a primitive parameter dict (plus chi, RC_target)."""
    q = {k: (np.array(v) if isinstance(v, np.ndarray) else v) for k, v in prim.items()}
    vals = {}
    for j, (k, (kind, a, b)) in enumerate(SPACE.items()):
        if kind == "abs":
            v = a + (b - a) * z[j]
        elif kind == "mul":
            v = a + (b - a) * z[j]
        else:
            v = float(np.exp(np.log(a) + (np.log(b) - np.log(a)) * z[j]))
        vals[k] = float(v)
    for k, v in vals.items():
        if k in ("RC_target", "chi"):
            continue
        if k == "kp_dur":
            q["kp_out"] = 1 / (v * 365.0)
        elif k == "kp_mult":
            q["kp_age"] = np.asarray(prim["kp_age"]) * v
        elif SPACE[k][0] == "abs":
            q[k] = v
        else:
            q[k] = prim[k] * v
    q["epsV"] = min(q["epsV"], 0.95); q["epsP"] = min(q["epsP"], 0.95)
    return q, vals


def worker():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from common import load_primitive
    from model import derive, plhiv, alive, NQ, NA, NR, G, IDX, NALIVE
    from repro import (R_C, R_H, ngm, spectral_radius, COVID_INF, HIV_DFE, KPMASK, U0, adult_prev, kp_prev,
                       art_cov, forces, jac_alive)
    from calibrate import calibrate
    from scenarios import all_scenarios
    import jax.numpy as jnp
    os.makedirs(ENS_DIR, exist_ok=True)
    prim0 = load_primitive()
    Z = design()
    for i in range(NSAMP):
        claim = os.path.join(ENS_DIR, f"claim_{i:04d}")
        done = os.path.join(ENS_DIR, f"sample_{i:04d}.json")
        try:
            fd = os.open(claim, os.O_CREAT | os.O_EXCL | os.O_WRONLY); os.close(fd)
        except FileExistsError:
            # re-claim samples abandoned by a stopped worker (claim older than 20 min, no output)
            if os.path.exists(done) or time.time() - os.path.getmtime(claim) < 1200:
                continue
            os.utime(claim)
        t0 = time.time()
        rec = {"i": i}
        try:
            q, vals = build(prim0, Z[i])
            rec["inputs"] = vals
            q["betaH"] = prim0["betaH"]; q["tau"] = prim0["tau"]
            prim, p, diag, (xH, xE, zH, zE) = calibrate(q, RC_target=vals["RC_target"])
            rec["calib"] = {k: v for k, v in diag.items() if k != "history"}
            rc, KC = R_C(p); rh, KH = R_H(p)
            nH = len(HIV_DFE)
            Pi = np.diag(np.tile(KPMASK, nH).astype(float)); Id = np.eye(KH.shape[0])
            rec["R_C"], rec["R_H"] = rc, rh
            from repro import foi_equilibrium, HIV_INF
            xC, _, _, _ = foi_equilibrium(p, "covid")
            rec["R_H_at_COVID_eq"] = spectral_radius(ngm(xC, p, HIV_INF, U0, "hiv")[0])
            rec["T_KP"] = spectral_radius(Pi @ KH @ np.linalg.inv(Id - (Id - Pi) @ KH))
            rec["R_H_lowrisk_only"] = spectral_radius((Id - Pi) @ KH @ (Id - Pi))
            Kx = ngm(xH, p, COVID_INF, U0, "covid")[0]
            cs = Kx.sum(axis=0).reshape(len(COVID_INF), G)
            ad = np.zeros((NA, NQ, NR)); ad[1:] = 1; ad = ad.reshape(G)
            def wm(v, w): return float((v * w).sum() / w.sum())
            rec["index_E"] = wm(cs[COVID_INF.index("E")], np.asarray(xH[IDX["S"]]) * ad)
            rec["index_CU"] = wm(cs[COVID_INF.index("CU")], np.asarray(xH[IDX["U"]]) * ad)
            lamC, lamH, N = forces(xE, U0, p)
            neg = sum(xE[IDX[k]] for k in ["S", "V", "R", "E", "EV", "A", "I"])
            rec["hiv_incidence_per_100k_yr"] = float((lamH * neg).sum() * 365e5)
            rec["kp_prev"] = kp_prev(xE)
            rec["coex_abscissa"] = float(np.linalg.eigvals(jac_alive(xE, p)).real.max())
            res, _ = all_scenarios(p, xE, chi=vals["chi"])
            rec["scenarios"] = res
            rec["ok"] = bool(diag["success"])
        except Exception as e:
            rec["ok"] = False; rec["error"] = traceback.format_exc()[-2000:]
        rec["time_s"] = time.time() - t0
        with open(os.path.join(ENS_DIR, f"sample_{i:04d}.json"), "w") as fh:
            json.dump(rec, fh, default=float)
        print(i, rec["ok"], round(rec["time_s"], 1), flush=True)


def prcc(X, y):
    R = np.column_stack([rankdata(c) for c in X.T]); ry = rankdata(y)
    out = []
    for j in range(R.shape[1]):
        A = np.column_stack([np.ones(len(ry)), np.delete(R, j, axis=1)])
        ex = R[:, j] - A @ np.linalg.lstsq(A, R[:, j], rcond=None)[0]
        ey = ry - A @ np.linalg.lstsq(A, ry, rcond=None)[0]
        out.append(np.corrcoef(ex, ey)[0, 1])
    return np.array(out)


def summarise():
    recs = []
    for f in sorted(os.listdir(ENS_DIR)):
        if f.startswith("sample_"):
            recs.append(json.load(open(os.path.join(ENS_DIR, f))))
    ok = [r for r in recs if r.get("ok")]
    out = {"n_total": len(recs), "n_ok": len(ok), "failures": [r["i"] for r in recs if not r.get("ok")]}
    def q(v):
        v = np.asarray(v, float)
        return {"median": float(np.median(v)), "q025": float(np.quantile(v, 0.025)), "q975": float(np.quantile(v, 0.975)),
                "min": float(v.min()), "max": float(v.max())}
    S = lambda r, k, f: r["scenarios"][k][f]
    metrics = {
        "R_H": [r["R_H"] for r in ok], "T_KP": [r["T_KP"] for r in ok], "R_H_lowrisk_only": [r["R_H_lowrisk_only"] for r in ok],
        "kp_prev_pct": [100 * r["kp_prev"] for r in ok], "hiv_incidence": [r["hiv_incidence_per_100k_yr"] for r in ok],
        "index_ratio_CU_E": [r["index_CU"] / r["index_E"] for r in ok],
        "deaths_S0": [S(r, "S0", "covid_deaths_per100k") for r in ok],
        "plhiv_deaths_S0": [S(r, "S0", "covid_deaths_PLHIV_per100k_PLHIV") for r in ok],
        "IFR_ratio": [S(r, "S0", "IFR_ratio_PLHIV_agestd") for r in ok],
        "RR_S0": [S(r, "S0", "RR_Q1_Q4") for r in ok],
        "disrupt_extra_hiv_pct": [100 * (S(r, "S1", "new_hiv_per100k") / S(r, "S0", "new_hiv_per100k") - 1) for r in ok],
        "rapidART_hiv_reduction_pct": [100 * (1 - S(r, "S2", "new_hiv_per100k") / S(r, "S0", "new_hiv_per100k")) for r in ok],
        "integrated_deaths_averted_pct": [100 * S(r, "S11", "covid_deaths_averted_per100k") / S(r, "S0", "covid_deaths_per100k") for r in ok],
        "coex_abscissa": [r["coex_abscissa"] for r in ok],
        "calib_max_resid": [max(abs(x) for x in r["calib"]["resid_coex"]) for r in ok],
        "R_H_at_COVID_eq": [r["R_H_at_COVID_eq"] for r in ok],
    }
    out["summary"] = {k: q(v) for k, v in metrics.items()}
    out["P_RH_gt_1"] = 1.0  # by construction: endemic HIV at calibration
    out["P_coex_stable"] = float(np.mean(np.asarray(metrics["coex_abscissa"]) < 0))
    # ---- ranking and equity robustness (probabilities over the ensemble)
    A = lambda r, k: S(r, k, "covid_deaths_averted_per100k")
    pr = {}
    pr["S7_vs_S4_deaths_within_5pct"] = np.mean([A(r, "S7") >= 0.95 * A(r, "S4") for r in ok])
    pr["S7_RR_lower_than_S4"] = np.mean([S(r, "S7", "RR_Q1_Q4") < S(r, "S4", "RR_Q1_Q4") for r in ok])
    pr["S7_RR_lower_than_S3"] = np.mean([S(r, "S7", "RR_Q1_Q4") < S(r, "S3", "RR_Q1_Q4") for r in ok])
    pr["S4_RR_higher_than_S0"] = np.mean([S(r, "S4", "RR_Q1_Q4") > S(r, "S0", "RR_Q1_Q4") for r in ok])
    pr["S4_more_than_S3"] = np.mean([A(r, "S4") > A(r, "S3") for r in ok])
    pr["S8_PLHIV_lower_than_S7"] = np.mean([S(r, "S8", "covid_deaths_PLHIV_per100k_PLHIV") < S(r, "S7", "covid_deaths_PLHIV_per100k_PLHIV") for r in ok])
    pr["S8_deaths_within_1pct_of_S7"] = np.mean([A(r, "S8") >= 0.99 * A(r, "S7") for r in ok])
    pr["S1_more_hiv_than_S0"] = np.mean([S(r, "S1", "new_hiv_per100k") > S(r, "S0", "new_hiv_per100k") for r in ok])
    pr["S10_more_than_S9"] = np.mean([A(r, "S10") > A(r, "S9") for r in ok])
    pr["S11_best_deaths"] = np.mean([A(r, "S11") >= max(A(r, k) for k in ["S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9", "S10"]) for r in ok])
    pr["S9_lowest_peak_single"] = np.mean([S(r, "S9", "peak_hosp_per100k") <= min(S(r, k, "peak_hosp_per100k") for k in ["S3", "S4", "S6", "S7", "S10"]) for r in ok])
    pr["RR_S0_gt_1"] = np.mean([S(r, "S0", "RR_Q1_Q4") > 1 for r in ok])
    out["ranking_probabilities"] = {k: float(v) for k, v in pr.items()}
    # deaths-averted ranking of single interventions per sample
    singles = ["S3", "S4", "S5", "S6", "S7", "S8", "S9", "S10"]
    ranks = np.array([rankdata([-A(r, k) for k in singles]) for r in ok])
    out["mean_rank_single"] = {k: float(ranks[:, j].mean()) for j, k in enumerate(singles)}
    out["P_rank1_single"] = {k: float(np.mean(ranks[:, j] == 1)) for j, k in enumerate(singles)}
    # ---- PRCC on the calibrated ensemble
    X = np.array([[r["inputs"][k] for k in NAMES_P] for r in ok])
    outs = {"R_H": metrics["R_H"], "T_KP": metrics["T_KP"], "deaths_S0": metrics["deaths_S0"],
            "plhiv_deaths_S0": metrics["plhiv_deaths_S0"], "RR_S0": metrics["RR_S0"],
            "disrupt_extra_hiv_pct": metrics["disrupt_extra_hiv_pct"],
            "S7_minus_S4_RR": [S(r, "S7", "RR_Q1_Q4") - S(r, "S4", "RR_Q1_Q4") for r in ok]}
    pc = {}; pv = {}
    dfree = len(ok) - 2 - (len(NAMES_P) - 1)
    for k, y in outs.items():
        v = prcc(X, np.asarray(y))
        pc[k] = v.tolist()
        pv[k] = [float(2 * tdist.sf(abs(r_) * np.sqrt(dfree / max(1 - r_ * r_, 1e-12)), dfree)) for r_ in v]
    out["prcc"] = {"params": NAMES_P, "values": pc, "pvalues": pv, "dof": dfree}
    out["metrics_raw"] = metrics
    json.dump(out, open(os.path.join(os.path.dirname(ENS_DIR), "E_uncertainty.json"), "w"), indent=1)
    print(json.dumps({k: v for k, v in out.items() if k not in ("prcc", "metrics_raw")}, indent=1))


if __name__ == "__main__":
    if sys.argv[1] == "worker":
        worker()
    else:
        summarise()
