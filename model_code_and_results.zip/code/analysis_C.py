"""Baseline immune-escape wave and policy scenarios (results/C_scenarios.json)."""
import json, time
import numpy as np
from common import *
from scenarios import all_scenarios, NAMES_SC

p = P(); xH, xE, zH, zE = equilibria()
t0 = time.time()
res, traj = all_scenarios(p, xE, chi=0.5, keep_traj=True)
json.dump({"scenarios": res, "names": NAMES_SC, "traj": traj}, open("results/C_scenarios.json", "w"), indent=1)
for k, v in res.items():
    print(f"{k:4s} {NAMES_SC[k]:40s} deaths {v['covid_deaths_per100k']:6.2f} PLHIV {v['covid_deaths_PLHIV_per100k_PLHIV']:6.1f} "
          f"HIV {v['new_hiv_per100k']:5.2f} AIDS {v['aids_deaths_per100k']:5.2f} doses {v['doses_per100k']:7.0f} "
          f"RR {v['RR_Q1_Q4']:.3f} gap {v['gap_Q1_Q4_per100k']:.2f} peakH {v['peak_hosp_per100k']:.2f}")
print("IFR ratio", res["S0"]["IFR_ratio_PLHIV_agestd"], "time", time.time() - t0)
